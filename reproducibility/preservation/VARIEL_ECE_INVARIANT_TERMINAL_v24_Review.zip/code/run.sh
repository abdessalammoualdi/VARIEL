#!/usr/bin/env bash
set -euo pipefail
ROOT="${DTRAR_PROJECT:-$HOME/Documents/DTRA_Start/DTRA}"
PY="$ROOT/.venv/bin/python"; [ -x "$PY" ] || PY=python3
HERE="$(cd "$(dirname "$0")" && pwd)"
mkdir -p "$ROOT/artifacts/logs"

echo "V24_PREFLIGHT_BEGIN"
[ -f "$ROOT/VARIEL_ECE_CLOSURE_v21_Review.zip" ] || { echo "ERROR missing V21 review"; exit 2; }
N=$(find "$ROOT/artifacts/variel_cross_backbone_all_final/endpoint_cache" -maxdepth 1 -name '*.pkl.gz' 2>/dev/null | wc -l)
echo "endpoint_caches=$N expected=200"
[ "$N" -eq 200 ] || { echo "ERROR expected 200 endpoint caches"; exit 3; }
echo "V24_PREFLIGHT_OK"

export DTRAR_PROJECT="$ROOT"
export PYTHONPATH="$ROOT:$ROOT/src:$HERE:${PYTHONPATH:-}"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1 NUMEXPR_NUM_THREADS=1

exec "$PY" -u "$HERE/run_v24.py"
