#!/usr/bin/env python3
from pathlib import Path
import hashlib,json,os,zipfile
import pandas as pd
HERE=Path(__file__).resolve().parent
PROJECT=Path(os.environ.get('DTRAR_PROJECT',str(Path.home()/'Documents'/'DTRA_Start'/'DTRA'))).resolve()
OUT=PROJECT/'artifacts'/'variel_highinfo_external_confirmation'
DSETS=['rialto','spam','insects','ble_rssi']

def must(c,m):
    if not c: raise RuntimeError(m)

ext=[]; summaries=[]
for ds in DSETS:
    p=OUT/ds/'EXTERNAL_SEEDWISE.csv'; must(p.exists(),f'missing {p}')
    d=pd.read_csv(p); must(len(d)==10,f'{ds}: expected 10 seeds')
    ext.append(d)
    summaries.append(json.loads((OUT/ds/'EXTERNAL_SUMMARY.json').read_text()))
ext=pd.concat(ext,ignore_index=True); ext.to_csv(OUT/'VARIEL_HIGHINFO_EXTERNAL_SEEDWISE.csv',index=False)
pd.DataFrame(summaries).to_csv(OUT/'VARIEL_HIGHINFO_EXTERNAL_SUMMARY.csv',index=False)
external_assessment={
 'architecture':'Frozen VARIEL HIGH-INFO FULL+REPAIR drawer',
 'external_datasets':['rialto','spam','insects','ble_rssi'],
 'development_datasets_touched':False,
 'frozen_highinfo_drawer_changed':False,
 'external_total_seed_decisions':int(len(ext)),
 'external_utility_wins_vs_raw_full_retrain':int((ext.improvement_vs_retrain>0).sum()),
 'external_safety_wins_vs_raw_full_retrain':int((ext.safety_improvement_vs_retrain>0).sum()),
 'all_40_external_utility_seeds_beat_raw_full_retrain':bool((ext.improvement_vs_retrain>0).all()),
 'all_40_external_safety_seeds_beat_raw_full_retrain':bool((ext.safety_improvement_vs_retrain>0).all()),
 'all_four_external_utility_means_beat_raw_full_retrain':bool(all(x['utility_mean_beats_raw_full_retrain'] for x in summaries)),
 'all_four_external_safety_means_beat_raw_full_retrain':bool(all(x['safety_mean_beats_raw_full_retrain'] for x in summaries)),
 'safety_H02_holds':bool((ext.max_safety_H<=.02+2e-9).all()),
 'raw_full_retraining_total_label_fraction':1.0,
 'highinfo_total_label_fraction':1.0,
 'external_perfect_gate':bool((ext.improvement_vs_retrain>0).all() and (ext.safety_improvement_vs_retrain>0).all() and (ext.max_safety_H<=.02+2e-9).all())
}
(OUT/'VARIEL_HIGHINFO_EXTERNAL_ASSESSMENT.json').write_text(json.dumps(external_assessment,indent=2,sort_keys=True))

# Combine with immutable four-development evidence packaged before external outcomes.
dev=pd.read_csv(HERE/'FROZEN_FOURDEV_SEEDWISE.csv')
dev=dev.copy(); dev['safety_improvement_vs_retrain']=dev.raw_retrain_brier-dev.safety02_brier
combined=pd.concat([dev,ext],ignore_index=True,sort=False)
combined.to_csv(OUT/'VARIEL_HIGHINFO_EIGHT_DATASET_SEEDWISE.csv',index=False)
combined_assessment={
 'development_datasets':['bank','electricity','gas','airlines'],
 'external_confirmation_datasets':['rialto','spam','insects','ble_rssi'],
 'total_datasets':8,'total_seed_decisions':int(len(combined)),
 'utility_wins_vs_raw_full_retrain':int((combined.improvement_vs_retrain>0).sum()),
 'safety_wins_vs_raw_full_retrain':int((combined.safety_improvement_vs_retrain>0).sum()),
 'all_80_utility_seeds_beat_raw_full_retrain':bool((combined.improvement_vs_retrain>0).all()),
 'all_80_safety_seeds_beat_raw_full_retrain':bool((combined.safety_improvement_vs_retrain>0).all()),
 'safety_H02_holds_all_eight':bool((combined.max_safety_H<=.02+2e-9).all()),
 'same_total_label_fraction_as_raw_full_retraining':True,
 'eight_dataset_perfect_gate':bool((combined.improvement_vs_retrain>0).all() and (combined.safety_improvement_vs_retrain>0).all() and (combined.max_safety_H<=.02+2e-9).all()),
 'interpretation_if_gate_passes':'Frozen HIGH-INFO FULL+REPAIR strictly dominates raw rolling full-feedback retraining in Brier at the same 100% total target-label fraction across all 8 datasets / 80 seeds, while the safety profile respects H<=0.02.'
}
(OUT/'VARIEL_HIGHINFO_EIGHT_DATASET_ASSESSMENT.json').write_text(json.dumps(combined_assessment,indent=2,sort_keys=True))

review=PROJECT/'VARIEL_HighInfoCabinet_ExternalConfirmation_Review.zip'
if review.exists(): review.unlink()
with zipfile.ZipFile(review,'w',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(OUT.rglob('*')):
        if p.is_file() and ('rolling_anchor_cache' not in p.parts): z.write(p,p.relative_to(OUT))
    for q in ['frozen_variel_highinfo_development.py','run_external_dataset.py','merge_external_results.py','FROZEN_FOURDEV_SEEDWISE.csv','FROZEN_FOURDEV_SUMMARY.csv','FROZEN_FOURDEV_ASSESSMENT.json']:
        z.write(HERE/q,q)
print('\n=== VARIEL HIGH-INFO EXTERNAL ASSESSMENT ===')
print(json.dumps(external_assessment,indent=2,sort_keys=True))
print('\n=== VARIEL HIGH-INFO EIGHT-DATASET ASSESSMENT ===')
print(json.dumps(combined_assessment,indent=2,sort_keys=True))
print(f'VARIEL_HIGHINFO_EXTERNAL_COMPLETE review={review.name}',flush=True)
