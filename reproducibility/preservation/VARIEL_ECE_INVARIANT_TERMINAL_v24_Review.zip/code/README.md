# VARIEL ECE-Invariant Terminal Closure v24

V24 fixes the exact defect in V23.

V23's nullspace residual was nonzero, but its numeric-bin-boundary scale rule
collapsed the update scale to zero because XGBoost/Spam contains tied baseline
probabilities at ECE-bin boundaries.

V24 instead:

1. adds equality constraints forcing tied baseline p1/confidence scores to move
   together;
2. projects the V20 residual into the ECE-invariant nullspace;
3. preserves the complete weak ordering directly with adjacent order
   inequalities instead of freezing numeric bin boundaries;
4. preserves hard binary decisions and probability bounds;
5. verifies ordinary ECE and classwise ECE equal the baseline to floating-point
   tolerance;
6. refuses to complete if any seed's projection scale collapses to zero.

Only XGBoost/Spam, 10 seeds.

No backbone retraining. No calibration fitting. No label-based tuning.

Run:

```bash
cd ~/Documents/DTRA_Start/DTRA
rm -rf VARIEL_ECE_INVARIANT_TERMINAL_v24
unzip -o VARIEL_ECE_INVARIANT_TERMINAL_v24.zip -d VARIEL_ECE_INVARIANT_TERMINAL_v24
cd VARIEL_ECE_INVARIANT_TERMINAL_v24

nohup setsid bash run.sh </dev/null \
  > ~/Documents/DTRA_Start/DTRA/artifacts/logs/v24.log 2>&1 & echo "V24_PID=$!"
```

Monitor:

```bash
tail -F ~/Documents/DTRA_Start/DTRA/artifacts/logs/v24.log
```

The critical diagnostic is that every line must show a nonzero scale:

`V24_DONE ... scale=...`

Final:
`~/Documents/DTRA_Start/DTRA/VARIEL_ECE_INVARIANT_TERMINAL_v24_Review.zip`
