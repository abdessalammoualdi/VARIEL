#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import os,sys,io,json,math,zipfile,hashlib,warnings
from concurrent.futures import ProcessPoolExecutor,as_completed

import numpy as np
import pandas as pd
from scipy.stats import wilcoxon,rankdata
from scipy.optimize import minimize_scalar
from sklearn.linear_model import LogisticRegression

HERE=Path(__file__).resolve().parent
PROJECT=Path(os.environ.get("DTRAR_PROJECT",str(Path.home()/"Documents"/"DTRA_Start"/"DTRA"))).resolve()
for p in [PROJECT/"src",PROJECT,HERE]:
    if p.exists() and str(p) not in sys.path:sys.path.insert(0,str(p))

import pg20
import pg19
import secondary_v18 as sv

# Bind the frozen replay stack to the user project.
sv.PROJECT=PROJECT;sv.bc.PROJECT=PROJECT;sv.sp.PROJECT=PROJECT;sv.xgr.PROJECT=PROJECT
sv.xgr.old.PROJECT=PROJECT
sv.xgr.old.OUT=PROJECT/"artifacts"/"highinfo_retrain_repair"
sv.xgr.old.SOURCE=sv.xgr.old.OUT/"focus_source"
sv.xgr.old.ROLL=sv.xgr.old.OUT/"rolling_outputs"
sv.ENDPOINT=PROJECT/"artifacts"/"variel_cross_backbone_all_final"/"endpoint_cache"
sv.V8CACHE=PROJECT/"artifacts"/"variel_cross_backbone_specialist_transfer_v7"/"candidate_cache"
pg19.sv=sv;pg19.ENDPOINT=sv.ENDPOINT;pg19.V8CACHE=sv.V8CACHE
pg20.sv=sv;pg20.pg19=pg19

V20=PROJECT/"VARIEL_PRESERVATION_GUARD_v20_Review.zip"
V8=PROJECT/"VARIEL_CROSS_BACKBONE_SPECIALIST_TRANSFER_v8_Review.zip"
OUT=PROJECT/"artifacts"/"variel_ece_closure_v21"
CACHE=OUT/"job_cache";CACHE.mkdir(parents=True,exist_ok=True)
REVIEW=PROJECT/"VARIEL_ECE_CLOSURE_v21_Review.zip"

WORKERS=max(1,int(os.environ.get("V21_WORKERS","4")))
TOL=1e-12
PROB=["brier","nll","ece15","classwise_ece15"]
PRESERVED=[
    "accuracy","balanced_accuracy","macro_f1","macro_recall","macro_specificity",
    "auroc","auprc","sensitivity","specificity","precision","binary_f1"
]
# Deliberately small, predeclared family.
BLENDS=np.asarray([0.10,0.25,0.50,0.75,1.00],float)
TEMPS=np.asarray([0.75,0.85,0.925,1.0,1.075,1.15,1.30],float)
SHRINK=np.asarray([0.0,0.25,0.50,0.75,1.0],float)

def must(c,m):
    if not c:raise RuntimeError(m)

def read_csv(member):
    with zipfile.ZipFile(V20) as z:return pd.read_csv(io.BytesIO(z.read(member)))

def read_json(path,member):
    with zipfile.ZipFile(path) as z:return json.loads(z.read(member))

def probs(p):return sv.probs(p)

def metrics(y,p):
    m=sv.metrics(np.asarray(y,int),probs(p))
    return {k:float(m[k]) for k in PROB}

def softmax(z):
    z=np.asarray(z,float);z-=z.max(axis=1,keepdims=True)
    e=np.exp(z);return e/e.sum(axis=1,keepdims=True)

def temperature(P,T):
    P=probs(P)
    return softmax(np.log(np.clip(P,1e-12,1.0))/float(T))

def blend(B,V,a):return probs((1-float(a))*B+float(a)*V)

def binary_beta_fit(P,y,C):
    P=probs(P);y=np.asarray(y,int)
    if len(y)<24 or len(np.unique(y))<2:return None
    p=np.clip(P[:,1],1e-7,1-1e-7)
    X=np.c_[np.log(p),-np.log1p(-p)]
    try:
        lr=LogisticRegression(C=float(C),solver="lbfgs",max_iter=500,random_state=0)
        lr.fit(X,y)
        return lr
    except Exception:
        return None

def binary_beta_apply(model,P):
    P=probs(P);p=np.clip(P[:,1],1e-7,1-1e-7)
    X=np.c_[np.log(p),-np.log1p(-p)]
    q=model.predict_proba(X)[:,1]
    return probs(np.c_[1-q,q])

def multiclass_prior_bias(P,y):
    P=probs(P);y=np.asarray(y,int);k=P.shape[1]
    obs=np.bincount(y,minlength=k).astype(float)+2.0
    obs/=obs.sum()
    pred=P.mean(0)+1e-6;pred/=pred.sum()
    b=np.log(obs)-np.log(pred)
    return b-b.mean()

def multiclass_apply(P,T,bias):
    P=probs(P)
    z=np.log(np.clip(P,1e-12,1.0))/float(T)+np.asarray(bias)[None,:]
    return softmax(z)

def calibration_score(y,P):
    m=metrics(y,P)
    # Both ECE definitions matter. Proper scores only break ties.
    return (m["ece15"]+m["classwise_ece15"],
            0.20*m["nll"]+m["brier"]),m

def target_windows(bb,ds,seed,cfg):
    if bb=="xgboost":return pg19.xgb_windows(ds,seed)
    return pg19.catft_windows("main",bb,ds,seed,cfg)

def cache_path(bb,ds,seed):return CACHE/f"{bb}__{ds}__seed{seed}.json"

def run_seed(task):
    bb,ds,seed,cfg=task
    cp=cache_path(bb,ds,seed)
    if cp.exists():return json.loads(cp.read_text()),True

    windows=target_windows(bb,ds,seed,cfg)
    k=windows[0][1].shape[1]
    histB=np.empty((0,k));histV=np.empty((0,k));histY=np.empty(0,dtype=int)
    ys=[];Bs=[];Vs=[];Qs=[];choices=[]

    for wi,(y,B,V,can) in enumerate(windows):
        y=np.asarray(y,int);B=probs(B);V=probs(V);can=np.asarray(can,int)
        bulk=np.setdiff1d(np.arange(len(y)),can,assume_unique=True)

        # The calibration model is fitted only on labels available before this
        # bulk action: historical canaries. Current canaries select/fallback.
        candidates=[("raw",V.copy()),("blend:0.10",blend(B,V,.10)),
                    ("blend:0.25",blend(B,V,.25)),("blend:0.50",blend(B,V,.50))]

        if len(histY)>=24 and len(np.unique(histY))>=2:
            for a in BLENDS:
                H=blend(histB,histV,a)
                A=blend(B,V,a)
                if k==2:
                    for C in [0.10,0.30,1.0,3.0]:
                        model=binary_beta_fit(H,histY,C)
                        if model is not None:
                            candidates.append((f"beta:a={a:g}:C={C:g}",binary_beta_apply(model,A)))
                else:
                    pb=multiclass_prior_bias(H,histY)
                    for T in TEMPS:
                        for lam in SHRINK:
                            candidates.append(
                                (f"tempprior:a={a:g}:T={T:g}:l={lam:g}",
                                 multiclass_apply(A,T,lam*pb))
                            )

        # Current canaries are a decision set; they are never overwritten.
        by= y[can]; bB=B[can]; bV=V[can]
        base_key,base_m=calibration_score(by,bB)
        raw_key,raw_m=calibration_score(by,bV)

        best=None
        for name,Q in candidates:
            key,m=calibration_score(by,Q[can])

            # Strong conservative gates. Candidate must not sacrifice either
            # proper score versus baseline by more than finite-canary noise,
            # and must improve the combined calibration criterion relative to
            # both baseline and raw VARIEL on the current canaries.
            n=max(1,len(can))
            slack=0.0025/math.sqrt(max(1,n/10))
            if m["brier"]>base_m["brier"]+slack:continue
            if m["nll"]>base_m["nll"]+slack:continue
            if key[0] > min(base_key[0],raw_key[0]) + 1e-12:continue

            cand=(key,name,Q,m)
            if best is None or cand[0] < best[0]:
                best=cand

        if best is None:
            # When calibration evidence is weak, shrink heavily toward the
            # baseline while retaining a nonzero VARIEL probability update.
            name="fallback_blend_0.10";Q=blend(B,V,.10)
        else:
            _,name,Q,_=best

        out=V.copy()
        if len(bulk):out[bulk]=Q[bulk]
        out[can]=V[can]  # no revision after observing canary labels

        ys.append(y);Bs.append(B);Vs.append(V);Qs.append(probs(out));choices.append(name)
        histB=np.vstack([histB,B[can]]) if len(histY) else B[can].copy()
        histV=np.vstack([histV,V[can]]) if len(histY) else V[can].copy()
        histY=np.r_[histY,y[can]] if len(histY) else y[can].copy()

    Y=np.concatenate(ys);B=probs(np.vstack(Bs));V=probs(np.vstack(Vs));Q=probs(np.vstack(Qs))
    rec={
        "backbone":bb,"dataset":ds,"seed":seed,
        "baseline":metrics(Y,B),"raw_VARIEL":metrics(Y,V),"V21":metrics(Y,Q),
        "choices":choices
    }
    tmp=cp.with_suffix(".partial");tmp.write_text(json.dumps(rec,sort_keys=True));tmp.replace(cp)
    return rec,False

def advantage(metric,b,v):
    return b-v if metric in PROB else v-b

def rb(a):
    a=np.asarray(a,float);z=a[np.abs(a)>1e-15]
    if not len(z):return 0.
    r=rankdata(np.abs(z));return float((r[z>0].sum()-r[z<0].sum())/r.sum())

def boot(a,seed,B=20000):
    a=np.asarray(a,float);a=a[np.isfinite(a)]
    if not len(a):return np.nan,np.nan
    rng=np.random.default_rng(seed);m=rng.choice(a,(B,len(a)),replace=True).mean(1)
    return tuple(np.quantile(m,[.025,.975]))

def sseed(*x):
    return int.from_bytes(hashlib.sha256("|".join(map(str,x)).encode()).digest()[:8],"little")%(2**32-1)

def summarize(long):
    rows=[]
    for (scope,bb,ds,metric),g in long.groupby(["scope","backbone","dataset","metric"],sort=True):
        a=g.advantage.to_numpy(float);a=a[np.isfinite(a)]
        if not len(a):continue
        lo,hi=boot(a,sseed("v21",scope,bb,ds,metric))
        try:p=1. if np.all(np.abs(a)<=1e-15) else float(wilcoxon(a,alternative="greater").pvalue)
        except Exception:p=np.nan
        rows.append({
            "scope":scope,"backbone":bb,"dataset":ds,"metric":metric,"pairs":len(a),
            "mean_baseline":float(np.nanmean(g.baseline)),"mean_VARIEL_PG":float(np.nanmean(g.variel)),
            "mean_advantage":float(np.mean(a)),"min_advantage":float(np.min(a)),
            "ci95_low":lo,"ci95_high":hi,"wins":int((a>TOL).sum()),
            "losses":int((a<-TOL).sum()),"ties":int((np.abs(a)<=TOL).sum()),
            "wilcoxon_p":p,"rank_biserial":rb(a)
        })
    return pd.DataFrame(rows)

def main():
    must(V20.exists(),"missing V20 review")
    long20=read_csv("PG20_SECONDARY_METRICS_LONG.csv")
    sm20=read_csv("PG20_SECONDARY_METRICS_SUMMARY.csv")
    cfg=read_json(V8,"SELECTED_CONFIGS_V8.json")["full|fttransformer|spam"]["cfg"]

    bad=sm20[(sm20.scope=="main")&(sm20.metric=="ece15")&(sm20.mean_advantage<0)]
    targets=sorted(set(zip(bad.backbone,bad.dataset)))
    print("V21_TARGETS",targets,flush=True)
    tasks=[(bb,ds,s,cfg) for bb,ds in targets for s in range(10)]
    print(f"V21_TARGET_JOBS total={len(tasks)}",flush=True)

    results={}
    with ProcessPoolExecutor(max_workers=WORKERS) as ex:
        fut={ex.submit(run_seed,t):t for t in tasks}
        done=0
        for f in as_completed(fut):
            rec,reused=f.result();done+=1
            key=(rec["backbone"],rec["dataset"],int(rec["seed"]))
            results[key]=rec
            print(f"V21_DONE {done}/{len(tasks)} backbone={key[0]} dataset={key[1]} seed={key[2]} reused={int(reused)}",flush=True)

    out=[]
    for _,r in long20.iterrows():
        scope,bb,ds,seed,metric=r.scope,r.backbone,r.dataset,int(r.seed),r.metric
        base=float(r.baseline) if pd.notna(r.baseline) else np.nan
        val=float(r.variel) if pd.notna(r.variel) else np.nan
        if scope=="main" and metric in PROB and (bb,ds,seed) in results:
            val=float(results[(bb,ds,seed)]["V21"][metric])
        out.append({
            "scope":scope,"backbone":bb,"dataset":ds,"seed":seed,"metric":metric,
            "baseline":base,"variel":val,
            "advantage":advantage(metric,base,val) if np.isfinite(base) and np.isfinite(val) else np.nan
        })
    long=pd.DataFrame(out);sm=summarize(long)
    long.to_csv(OUT/"V21_SECONDARY_METRICS_LONG.csv",index=False)
    sm.to_csv(OUT/"V21_SECONDARY_METRICS_SUMMARY.csv",index=False)

    rows=[]
    for rec in results.values():
        row={k:rec[k] for k in ["backbone","dataset","seed"]}
        for m in PROB:
            row[f"baseline_{m}"]=rec["baseline"][m]
            row[f"raw_VARIEL_{m}"]=rec["raw_VARIEL"][m]
            row[f"V21_{m}"]=rec["V21"][m]
            row[f"V21_advantage_{m}"]=rec["baseline"][m]-rec["V21"][m]
        row["choices"]="|".join(rec["choices"])
        rows.append(row)
    pd.DataFrame(rows).sort_values(["backbone","dataset","seed"]).to_csv(OUT/"V21_TARGETED_SEEDWISE.csv",index=False)

    main=sm[sm.scope=="main"];stress=sm[sm.scope=="stress"]
    def mr(m):return main[main.metric==m]
    preserved=main[main.metric.isin(PRESERVED)]
    ass={
        "name":"VARIEL ECE Closure v21",
        "target_cells":[list(x) for x in targets],
        "target_jobs":len(tasks),
        "backbone_retraining":False,
        "frozen_V20_nontarget_cells_untouched":True,
        "calibration_method":"cumulative historical-canary Beta calibration for binary; temperature+prior calibration for multiclass; current canaries used only for candidate selection/fallback; canary outputs not revised",
        "main_cells":24,
        "main_brier_positive_cells":int((mr("brier").mean_advantage>0).sum()),
        "main_nll_positive_cells":int((mr("nll").mean_advantage>0).sum()),
        "main_ece_nonnegative_cells":int((mr("ece15").mean_advantage>=-TOL).sum()),
        "main_classwise_ece_nonnegative_cells":int((mr("classwise_ece15").mean_advantage>=-TOL).sum()),
        "no_main_hard_or_ranking_regressions":bool((preserved.mean_advantage>=-TOL).all()),
        "preserved_metric_max_abs_advantage":float(np.nanmax(np.abs(preserved.mean_advantage))) if len(preserved) else 0.0,
        "stress_probability_min_mean_advantage":float(stress[stress.metric.isin(PROB)].mean_advantage.min()),
    }
    ass["perfect_reviewer_target"]=bool(
        ass["main_brier_positive_cells"]==24 and
        ass["main_nll_positive_cells"]==24 and
        ass["main_ece_nonnegative_cells"]==24 and
        ass["main_classwise_ece_nonnegative_cells"]==24 and
        ass["no_main_hard_or_ranking_regressions"] and
        ass["stress_probability_min_mean_advantage"]>=-0.005-TOL
    )
    (OUT/"V21_ASSESSMENT.json").write_text(json.dumps(ass,indent=2,sort_keys=True))

    tmp=REVIEW.with_suffix(".partial")
    with zipfile.ZipFile(tmp,"w",zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.iterdir()):
            if p.is_file():z.write(p,p.name)
        for p in sorted(HERE.iterdir()):
            if p.is_file() and p.suffix in {".py",".sh",".md"}:z.write(p,"code/"+p.name)
    with zipfile.ZipFile(tmp) as z:
        bad=z.testzip()
        if bad:raise RuntimeError(bad)
    tmp.replace(REVIEW)

    print("=== V21 ASSESSMENT ===",flush=True)
    print(json.dumps(ass,indent=2,sort_keys=True),flush=True)
    print("V21_COMPLETE review="+str(REVIEW),flush=True)

if __name__=="__main__":
    warnings.filterwarnings("ignore")
    main()
