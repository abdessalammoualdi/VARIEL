#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import os, io, json, math, time, gzip, pickle, zipfile, hashlib
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon, rankdata

PROJECT=Path(os.environ.get("DTRAR_PROJECT",str(Path.home()/"Documents"/"DTRA_Start"/"DTRA"))).resolve()
CACHE=PROJECT/"artifacts"/"variel_cross_backbone_all_final"/"endpoint_cache"
V9=PROJECT/"VARIEL_OCCUPANCY_LTT_TERMINAL_v9_Review.zip"
XB=PROJECT/"VARIEL_CROSS_BACKBONE_ALL_FINAL_Review.zip"
OUT=PROJECT/"artifacts"/"variel_final_code_freeze_v10"
OUT.mkdir(parents=True,exist_ok=True)

DATASETS=["gas","rialto","insects","ble_rssi"]
BACKBONES=["catboost","fttransformer"]
SEEDS=range(10)
TEMPS=[0.50,0.67,0.80,1.25,1.50,2.00]
ALPHA=.05
TOL=1e-12

def probs(p):
    p=np.asarray(p,float);p=np.clip(p,1e-12,np.inf)
    return p/p.sum(axis=1,keepdims=True)

def br_rows(p,y):
    p=probs(p);y=np.asarray(y,int)
    z=np.zeros_like(p);z[np.arange(len(y)),y]=1.
    return np.sum((p-z)**2,axis=1)

def brier(p,y):
    return float(np.mean(br_rows(p,y)))

def temp(p,T):
    p=probs(p);z=np.log(np.clip(p,1e-12,1.))/float(T)
    z-=z.max(axis=1,keepdims=True)
    return probs(np.exp(z))

def holm_reject(names,pvals,alpha=.05):
    order=np.argsort(pvals);rej=[]
    for rank,j in enumerate(order):
        if pvals[j] <= alpha/(len(pvals)-rank):
            rej.append(names[j])
        else:
            break
    return set(rej)

def load_obj(bb,ds,s):
    p=CACHE/f"{bb}__{ds}__seed{s}.pkl.gz"
    if not p.exists():raise RuntimeError(f"Missing frozen endpoint cache: {p}")
    with gzip.open(p,"rb") as f:return pickle.load(f)

def read_zip_csv(path,name):
    with zipfile.ZipFile(path) as z:return pd.read_csv(io.BytesIO(z.read(name)))

def read_zip_json(path,name):
    with zipfile.ZipFile(path) as z:return json.loads(z.read(name))

def ltt_window(w):
    """Pre-specified multiclass LTT temperature-family selector.

    Hypotheses are fixed before seeing target labels. The current 5% canaries are
    used only for testing; they are never used to fit the candidate predictions.
    Brier differences lie in [-2,2], so Hoeffding:
      P(mean(d) >= g | E[d] <= 0) <= exp(-n*g^2/8).
    Holm controls FWER across the temperature family.
    """
    raw=probs(w["static"]);y=np.asarray(w["y"],int);can=np.asarray(w["can5"],int)
    n=max(1,len(can))
    names=[];pvals=[];cand={}
    rawloss=br_rows(raw[can],y[can])
    for T in TEMPS:
        q=temp(raw,T)
        d=rawloss-br_rows(q[can],y[can])
        g=float(np.mean(d))
        pv=math.exp(-n*max(0.,g)**2/8.) if g>0 else 1.
        name=f"T={T:g}"
        names.append(name);pvals.append(min(1.,pv));cand[name]=(q,g,float(np.mean(br_rows(q[can],y[can]))))
    rejected=holm_reject(names,pvals,ALPHA)
    if not rejected:
        return raw,"STATIC",0,len(can),0.0
    # Among simultaneously certified candidates, choose lowest audited Brier.
    chosen=min(rejected,key=lambda n:(cand[n][2],n))
    q=cand[chosen][0].copy()
    # Audited points remain raw; only the unaudited bulk receives the selected transform.
    q[can]=raw[can]
    return q,chosen,len(rejected),len(can),cand[chosen][1]

def ltt_seed(bb,ds,s):
    obj=load_obj(bb,ds,s)
    ps=[];ys=[];accepted=0;tested=0;gains=[];choices=[]
    t0=time.perf_counter()
    for w in obj["windows"]:
        q,name,k,n,g=ltt_window(w)
        ps.append(q);ys.append(np.asarray(w["y"],int))
        accepted+=int(name!="STATIC");tested+=k;gains.append(g);choices.append(name)
    sec=time.perf_counter()-t0
    Y=np.concatenate(ys)
    return {
        "backbone":bb,"dataset":ds,"seed":s,
        "ltt_mc_brier":brier(np.vstack(ps),Y),
        "ltt_selected_windows":accepted,
        "windows":len(obj["windows"]),
        "significant_hypotheses_total":tested,
        "mean_selected_audit_gain":float(np.mean(gains)),
        "selector_seconds":sec,
        "selector_seconds_per_window":sec/max(1,len(obj["windows"])),
        "label_fraction":float(obj["label5_fraction"]),
        "dominant_choice":pd.Series(choices).value_counts().index[0]
    }

def rank_biserial(a):
    a=np.asarray(a,float);z=a[np.abs(a)>1e-15]
    if not len(z):return 0.
    r=rankdata(np.abs(z))
    return float((r[z>0].sum()-r[z<0].sum())/r.sum())

def boot(a,seed,B=20000):
    a=np.asarray(a,float);rng=np.random.default_rng(seed)
    m=rng.choice(a,(B,len(a)),replace=True).mean(axis=1)
    return tuple(np.quantile(m,[.025,.975]))

def stable_seed(*x):
    h=hashlib.sha256("|".join(map(str,x)).encode()).digest()
    return int.from_bytes(h[:8],"little")%(2**32-1)

def main():
    # Verify frozen V9 first.
    ass=read_zip_json(V9,"ASSESSMENT_V9.json")
    required=["all_CI_lower_positive","all_Holm_significant","all_rank_biserial_one","all_rows_perfect"]
    if not all(bool(ass.get(k)) for k in required) or int(ass.get("seed_losses",-1))!=0 or int(ass.get("seed_wins",-1))!=720:
        raise RuntimeError("Frozen V9 is not the expected perfect 720/720 result")

    v9=read_zip_csv(V9,"PAIRED_COMPARISONS_V9.csv")
    xbs=read_zip_csv(XB,"CROSS_BACKBONE_SEEDWISE.csv")
    # Matched 5% final VARIEL output is the final Periodic-comparison drawer.
    var=v9[(v9.comparator=="Periodic-5%-recalibration") & v9.dataset.isin(DATASETS)][
        ["backbone","dataset","seed","variel_brier","variel"]
    ].copy()
    if len(var)!=80:raise RuntimeError(f"Expected 80 final multiclass VARIEL rows, got {len(var)}")

    # Sanity audit only: final VARIEL must already strictly beat STATIC on every
    # multiclass cross-backbone seed. This is NOT used by the selector itself.
    st=xbs[(xbs.method=="Static/HOLD") & xbs.dataset.isin(DATASETS)][
        ["backbone","dataset","seed","brier"]
    ].rename(columns={"brier":"static_brier"})
    audit=var.merge(st,on=["backbone","dataset","seed"],validate="one_to_one")
    audit["advantage_vs_static"]=audit.static_brier-audit.variel_brier
    audit.to_csv(OUT/"LTT_MC_STATIC_DOMINANCE_AUDIT.csv",index=False)
    if not (audit.advantage_vs_static>TOL).all():
        raise RuntimeError("Unexpected: final 5% VARIEL does not dominate STATIC on every multiclass seed")

    rows=[]
    total=80
    done=0
    for bb in BACKBONES:
        for ds in DATASETS:
            for s in SEEDS:
                rows.append(ltt_seed(bb,ds,s));done+=1
                print(f"LTT_MC_DONE {done}/{total} backbone={bb} dataset={ds} seed={s}",flush=True)
    ltt=pd.DataFrame(rows)
    p=ltt.merge(var,on=["backbone","dataset","seed"],validate="one_to_one")
    p["variel_advantage"]=p.ltt_mc_brier-p.variel_brier
    p.to_csv(OUT/"LTT_MC_CROSS_BACKBONE_SEEDWISE.csv",index=False)

    sums=[]
    for (bb,ds),g in p.groupby(["backbone","dataset"],sort=True):
        a=g.variel_advantage.to_numpy(float);lo,hi=boot(a,stable_seed("lttmc",bb,ds))
        try:wp=float(wilcoxon(a,alternative="greater").pvalue)
        except Exception:wp=float("nan")
        sums.append({
            "backbone":bb,"dataset":ds,"pairs":len(g),
            "mean_LTT_MC_brier":float(g.ltt_mc_brier.mean()),
            "mean_VARIEL_brier":float(g.variel_brier.mean()),
            "mean_VARIEL_advantage":float(a.mean()),
            "min_VARIEL_advantage":float(a.min()),
            "ci95_low":lo,"ci95_high":hi,
            "wins":int((a>TOL).sum()),"losses":int((a<-TOL).sum()),"ties":int((np.abs(a)<=TOL).sum()),
            "wilcoxon_p":wp,"rank_biserial":rank_biserial(a),
            "mean_LTT_label_fraction":float(g.label_fraction.mean()),
            "mean_LTT_selector_seconds_per_window":float(g.selector_seconds_per_window.mean()),
            "selected_windows_total":int(g.ltt_selected_windows.sum())
        })
    sm=pd.DataFrame(sums)
    # Holm over all 8 backbone x dataset comparisons.
    pv=sm.wilcoxon_p.to_numpy(float);order=np.argsort(pv);adj=np.empty(len(pv));run=0.
    for rank,j in enumerate(order):
        val=min(1.,(len(pv)-rank)*pv[j]);run=max(run,val);adj[j]=run
    sm["holm_p"]=adj
    sm.to_csv(OUT/"LTT_MC_CROSS_BACKBONE_SUMMARY.csv",index=False)

    losses=p[p.variel_advantage<-TOL].copy()
    losses.to_csv(OUT/"LTT_MC_LOSSES.csv",index=False)
    assessment={
        "name":"LTT-MC temperature-family sensitivity",
        "status":"pre-specified multiclass Brier Learn-Then-Test instantiation; not the original authors' binary MCGrad benchmark",
        "datasets":DATASETS,"backbones":BACKBONES,
        "paired_cells":int(len(p)),
        "VARIEL_wins":int((p.variel_advantage>TOL).sum()),
        "VARIEL_losses":int((p.variel_advantage<-TOL).sum()),
        "ties":int((np.abs(p.variel_advantage)<=TOL).sum()),
        "perfect":bool((p.variel_advantage>TOL).all()),
        "perfect_10of10_rows":int(((sm.wins==10)&(sm.losses==0)).sum()),
        "rows":int(len(sm)),
        "all_CI_lower_positive":bool((sm.ci95_low>0).all()),
        "all_Holm_significant":bool((sm.holm_p<.05).all()),
        "all_rank_biserial_one":bool(np.allclose(sm.rank_biserial,1.,atol=1e-12)),
        "target_label_budget":"same frozen 5% canary budget; hypotheses are fixed temperature transforms and use canaries only for testing",
        "FWER_alpha":ALPHA,
        "risk":"multiclass Brier, paired bounded-difference Hoeffding p-values, Holm FWER control",
        "future_label_leakage":False
    }
    (OUT/"LTT_MC_ASSESSMENT.json").write_text(json.dumps(assessment,indent=2,sort_keys=True))
    print("=== LTT-MC ASSESSMENT ===")
    print(json.dumps(assessment,indent=2,sort_keys=True))

if __name__=="__main__":
    main()
