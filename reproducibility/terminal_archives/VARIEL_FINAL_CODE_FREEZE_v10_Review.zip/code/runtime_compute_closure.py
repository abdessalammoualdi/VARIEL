#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import os,io,json,zipfile,re,platform,subprocess,hashlib
import numpy as np
import pandas as pd

PROJECT=Path(os.environ.get("DTRAR_PROJECT",str(Path.home()/"Documents"/"DTRA_Start"/"DTRA"))).resolve()
OUT=PROJECT/"artifacts"/"variel_final_code_freeze_v10";OUT.mkdir(parents=True,exist_ok=True)

def csvz(zname,name):
    p=PROJECT/zname
    if not p.exists():raise RuntimeError(f"Missing {p}")
    with zipfile.ZipFile(p) as z:return pd.read_csv(io.BytesIO(z.read(name)))

def jsons(zname):
    p=PROJECT/zname;rows=[]
    if not p.exists():raise RuntimeError(f"Missing {p}")
    with zipfile.ZipFile(p) as z:
        for n in z.namelist():
            if re.match(r".+_seed\d+\.json$",n):
                d=json.loads(z.read(n));d["_member"]=n;rows.append(d)
    return pd.DataFrame(rows)

def sha(p):
    h=hashlib.sha256()
    with open(p,"rb") as f:
        for b in iter(lambda:f.read(1<<20),b""):h.update(b)
    return h.hexdigest()

def main():
    # Matched whole-system runtime run.
    comp=jsons("VARIEL_COMPASS_INDEPENDENT_FINAL_Review.zip")
    upf=jsons("VARIEL_vs_UPF_Review.zip")
    sev=csvz("VARIEL_vs_SeverityAware_Review.zip","COMPARATOR_SEEDWISE_ALL.csv")

    c=comp[["dataset","seed","training_seconds","decision_seconds","total_seconds","windows","label_fraction","max_H"]].copy()
    c=c.rename(columns={x:f"VARIEL_{x}" for x in ["training_seconds","decision_seconds","total_seconds","windows","label_fraction","max_H"]})
    u=upf[["dataset","seed","training_seconds","decision_seconds","total_seconds","windows","comparator_seconds_per_window"]].copy()
    u=u.rename(columns={x:f"UPF_{x}" for x in ["training_seconds","decision_seconds","total_seconds","windows"]})
    u=u.rename(columns={"comparator_seconds_per_window":"UPF_seconds_per_window"})
    s=sev[["dataset","seed","training_seconds","decision_seconds","total_seconds","windows","comparator_seconds_per_window"]].copy()
    s=s.rename(columns={x:f"Severity_{x}" for x in ["training_seconds","decision_seconds","total_seconds","windows"]})
    s=s.rename(columns={"comparator_seconds_per_window":"Severity_seconds_per_window"})
    m=c.merge(u,on=["dataset","seed"],validate="one_to_one").merge(s,on=["dataset","seed"],validate="one_to_one")
    if len(m)!=80:raise RuntimeError(f"Expected 80 matched runtime seeds, got {len(m)}")
    for method in ["VARIEL","UPF","Severity"]:
        m[f"{method}_decision_seconds_per_window"]=m[f"{method}_decision_seconds"]/m[f"{method}_windows"]
        m[f"{method}_training_seconds_per_window"]=m[f"{method}_training_seconds"]/m[f"{method}_windows"]
        m[f"{method}_total_seconds_per_window"]=m[f"{method}_total_seconds"]/m[f"{method}_windows"]
    m["VARIEL_decision_faster_than_UPF"]=m.VARIEL_decision_seconds_per_window<m.UPF_decision_seconds_per_window
    m["VARIEL_decision_faster_than_Severity"]=m.VARIEL_decision_seconds_per_window<m.Severity_decision_seconds_per_window
    m["UPF_over_VARIEL_decision_ratio"]=m.UPF_decision_seconds_per_window/m.VARIEL_decision_seconds_per_window
    m["Severity_over_VARIEL_decision_ratio"]=m.Severity_decision_seconds_per_window/m.VARIEL_decision_seconds_per_window
    m["VARIEL_total_faster_than_UPF"]=m.VARIEL_total_seconds_per_window<m.UPF_total_seconds_per_window
    m["VARIEL_total_faster_than_Severity"]=m.VARIEL_total_seconds_per_window<m.Severity_total_seconds_per_window
    m.to_csv(OUT/"MATCHED_RUNTIME_SEEDWISE.csv",index=False)

    byds=m.groupby("dataset",as_index=False).agg(
        VARIEL_decision_seconds_per_window=("VARIEL_decision_seconds_per_window","mean"),
        UPF_decision_seconds_per_window=("UPF_decision_seconds_per_window","mean"),
        Severity_decision_seconds_per_window=("Severity_decision_seconds_per_window","mean"),
        VARIEL_training_seconds_per_window=("VARIEL_training_seconds_per_window","mean"),
        UPF_training_seconds_per_window=("UPF_training_seconds_per_window","mean"),
        Severity_training_seconds_per_window=("Severity_training_seconds_per_window","mean"),
        VARIEL_total_seconds_per_window=("VARIEL_total_seconds_per_window","mean"),
        UPF_total_seconds_per_window=("UPF_total_seconds_per_window","mean"),
        Severity_total_seconds_per_window=("Severity_total_seconds_per_window","mean"),
        VARIEL_decision_faster_UPF_seeds=("VARIEL_decision_faster_than_UPF","sum"),
        VARIEL_decision_faster_Severity_seeds=("VARIEL_decision_faster_than_Severity","sum"),
        VARIEL_total_faster_UPF_seeds=("VARIEL_total_faster_than_UPF","sum"),
        VARIEL_total_faster_Severity_seeds=("VARIEL_total_faster_than_Severity","sum"),
        VARIEL_label_fraction=("VARIEL_label_fraction","mean"),
        VARIEL_max_H=("VARIEL_max_H","max")
    )
    byds["UPF_over_VARIEL_decision_ratio"]=byds.UPF_decision_seconds_per_window/byds.VARIEL_decision_seconds_per_window
    byds["Severity_over_VARIEL_decision_ratio"]=byds.Severity_decision_seconds_per_window/byds.VARIEL_decision_seconds_per_window
    byds.to_csv(OUT/"MATCHED_RUNTIME_BY_DATASET.csv",index=False)

    # Final targeted Compass-SR research-generation upper bounds (not optimized deployment time).
    sr=csvz("VARIEL_COMPASS_SR_FINAL_Review.zip","COMPASS_SR_TARGETED_SEEDWISE.csv")
    wins=comp[["dataset","seed","windows"]].rename(columns={"windows":"window_count"})
    sr=sr.merge(wins,on=["dataset","seed"],how="left",validate="one_to_one")
    sr["generation_training_seconds_per_window"]=sr.generation_training_seconds/sr.window_count
    sr.to_csv(OUT/"FINAL_COMPASS_SR_GENERATION_UPPER_BOUND.csv",index=False)

    # Final 80/80 HI guard/controller replay runtime.
    hi=csvz("VARIEL_Final_80of80_Evidence_Review.zip","FINAL_HI_GUARD_RUNTIME_SUMMARY.csv")
    hi.to_csv(OUT/"FINAL_HI_GUARD_RUNTIME_SUMMARY.csv",index=False)

    assessment={
        "scope":"final compute/runtime evidence closure with matched runtime dimensions separated",
        "matched_whole_system_seeds":80,
        "VARIEL_decision_overhead_wins_vs_UPF":int(m.VARIEL_decision_faster_than_UPF.sum()),
        "VARIEL_decision_overhead_wins_vs_SeverityAware":int(m.VARIEL_decision_faster_than_Severity.sum()),
        "mean_VARIEL_decision_seconds_per_window":float(m.VARIEL_decision_seconds_per_window.mean()),
        "mean_UPF_decision_seconds_per_window":float(m.UPF_decision_seconds_per_window.mean()),
        "mean_Severity_decision_seconds_per_window":float(m.Severity_decision_seconds_per_window.mean()),
        "mean_UPF_over_VARIEL_decision_ratio":float(m.UPF_decision_seconds_per_window.mean()/m.VARIEL_decision_seconds_per_window.mean()),
        "mean_Severity_over_VARIEL_decision_ratio":float(m.Severity_decision_seconds_per_window.mean()/m.VARIEL_decision_seconds_per_window.mean()),
        "VARIEL_end_to_end_wins_vs_UPF":int(m.VARIEL_total_faster_than_UPF.sum()),
        "VARIEL_end_to_end_wins_vs_SeverityAware":int(m.VARIEL_total_faster_than_Severity.sum()),
        "universal_end_to_end_runtime_superiority":bool(m.VARIEL_total_faster_than_UPF.all() and m.VARIEL_total_faster_than_Severity.all()),
        "interpretation":[
            "VARIEL controller/decision overhead is a separate compute dimension from training/retraining endpoint generation.",
            "The matched whole-system run provides direct decision/training/total timing against UPF and Severity-Aware on the same 80 dataset-seed cells.",
            "Final Compass-SR targeted generation time is retained as a conservative research-generator upper bound, not relabeled as optimized deployment runtime.",
            "Do not claim universal end-to-end wall-clock superiority if the total-time columns do not support it."
        ]
    }
    (OUT/"RUNTIME_COMPUTE_ASSESSMENT.json").write_text(json.dumps(assessment,indent=2,sort_keys=True))

    # Hardware/software provenance snapshots already recorded during matched runs.
    blocks=[]
    for zn in ["VARIEL_vs_UPF_Review.zip","VARIEL_vs_SeverityAware_Review.zip"]:
        p=PROJECT/zn
        with zipfile.ZipFile(p) as z:
            if "HARDWARE_SOFTWARE.txt" in z.namelist():
                blocks.append(f"===== {zn} =====\n"+z.read("HARDWARE_SOFTWARE.txt").decode(errors="replace"))
    try:
        now=subprocess.check_output(["nvidia-smi","--query-gpu=index,name,memory.total,driver_version","--format=csv,noheader"],text=True,stderr=subprocess.STDOUT)
    except Exception as e:
        now=f"nvidia-smi unavailable: {e}"
    blocks.append("===== FINAL CLOSURE HOST SNAPSHOT =====\n"+platform.platform()+"\nPython "+platform.python_version()+"\n"+now)
    (OUT/"HARDWARE_SOFTWARE_PROVENANCE.txt").write_text("\n\n".join(blocks))

    print("=== RUNTIME COMPUTE ASSESSMENT ===")
    print(json.dumps(assessment,indent=2,sort_keys=True))

if __name__=="__main__":
    main()
