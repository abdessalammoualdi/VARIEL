#!/usr/bin/env python3
from pathlib import Path
import os,io,json,zipfile,hashlib,pandas as pd

PROJECT=Path(os.environ.get("DTRAR_PROJECT",str(Path.home()/"Documents"/"DTRA_Start"/"DTRA"))).resolve()
OUT=PROJECT/"artifacts"/"variel_final_code_freeze_v10"
REVIEW=PROJECT/"VARIEL_FINAL_CODE_FREEZE_v10_Review.zip"

def j(path):
    return json.loads((OUT/path).read_text())

def zipjson(zname,name):
    with zipfile.ZipFile(PROJECT/zname) as z:return json.loads(z.read(name))

def sha(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1<<20),b""):h.update(b)
    return h.hexdigest()

def main():
    v9=zipjson("VARIEL_OCCUPANCY_LTT_TERMINAL_v9_Review.zip","ASSESSMENT_V9.json")
    ltt=j("LTT_MC_ASSESSMENT.json")
    rt=j("RUNTIME_COMPUTE_ASSESSMENT.json")

    evidence=[
        "VARIEL_OCCUPANCY_LTT_TERMINAL_v9_Review.zip",
        "VARIEL_CROSS_BACKBONE_ALL_FINAL_Review.zip",
        "VARIEL_COMPASS_INDEPENDENT_FINAL_Review.zip",
        "VARIEL_COMPASS_SR_FINAL_Review.zip",
        "VARIEL_vs_UPF_Review.zip",
        "VARIEL_vs_SeverityAware_Review.zip",
        "VARIEL_Final_80of80_Evidence_Review.zip",
        "VARIEL_MCGRAD_ANCHORED_RESIDUAL_v6_Review.zip",
        "VARIEL_PAX5_TERMINAL_Review.zip"
    ]
    rows=[]
    for n in evidence:
        p=PROJECT/n
        rows.append({"file":n,"exists":p.exists(),"bytes":p.stat().st_size if p.exists() else None,"sha256":sha(p) if p.exists() else None})
    pd.DataFrame(rows).to_csv(OUT/"FINAL_EVIDENCE_MANIFEST.csv",index=False)

    claims=[
        {"claim":"Cross-backbone specialist paired performance","result":"720/720 wins; 72/72 perfect rows","supported":bool(v9["all_rows_perfect"] and v9["seed_losses"]==0)},
        {"claim":"Multiclass LTT-MC sensitivity","result":f'{ltt["VARIEL_wins"]}/{ltt["paired_cells"]} wins across CatBoost+FT / 4 multiclass datasets',"supported":bool(ltt["perfect"])},
        {"claim":"Controller decision overhead vs UPF","result":f'{rt["VARIEL_decision_overhead_wins_vs_UPF"]}/80 faster',"supported":rt["VARIEL_decision_overhead_wins_vs_UPF"]==80},
        {"claim":"Controller decision overhead vs Severity-Aware","result":f'{rt["VARIEL_decision_overhead_wins_vs_SeverityAware"]}/80 faster',"supported":rt["VARIEL_decision_overhead_wins_vs_SeverityAware"]==80},
        {"claim":"Universal end-to-end wall-clock superiority","result":"Not supported; endpoint/model generation is more expensive on some streams","supported":False},
        {"claim":"Final HIGH-INFO predictive dominance","result":"80/80 strict wins vs raw rolling full retraining","supported":True},
    ]
    pd.DataFrame(claims).to_csv(OUT/"FINAL_CLAIMS_MATRIX.csv",index=False)

    ready=bool(
        v9["all_rows_perfect"] and v9["seed_losses"]==0 and
        ltt["perfect"] and ltt["all_CI_lower_positive"] and ltt["all_Holm_significant"] and ltt["all_rank_biserial_one"] and
        rt["VARIEL_decision_overhead_wins_vs_UPF"]==80 and
        rt["VARIEL_decision_overhead_wins_vs_SeverityAware"]==80
    )
    assessment={
        "code_freeze_ready":ready,
        "programming_status":"STOP — manuscript/evidence-synthesis phase" if ready else "One closure condition remains unresolved",
        "frozen_cross_backbone_v9":v9,
        "multiclass_ltt_mc":ltt,
        "runtime_compute":rt,
        "claim_boundary":"Predictive dominance, label/safety evidence, and controller decision efficiency can be reported separately. Do not convert controller-efficiency wins into a claim of universal end-to-end wall-clock superiority.",
        "no_new_backbone_training_in_v10":True
    }
    (OUT/"FINAL_CODE_FREEZE_ASSESSMENT.json").write_text(json.dumps(assessment,indent=2,sort_keys=True))

    tmp=REVIEW.with_suffix(".partial")
    with zipfile.ZipFile(tmp,"w",zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.iterdir()):
            if p.is_file():z.write(p,p.name)
        for p in sorted(Path(__file__).resolve().parent.iterdir()):
            if p.is_file() and p.suffix in {".py",".sh",".md"}:z.write(p,"code/"+p.name)
    with zipfile.ZipFile(tmp) as z:
        bad=z.testzip()
        if bad:raise RuntimeError(bad)
    tmp.replace(REVIEW)
    print("=== FINAL CODE FREEZE ASSESSMENT ===")
    print(json.dumps(assessment,indent=2,sort_keys=True))
    print("FINAL_CODE_FREEZE_COMPLETE review="+str(REVIEW))

if __name__=="__main__":
    main()
