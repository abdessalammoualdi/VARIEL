#!/usr/bin/env bash
set -euo pipefail
ROOT="${DTRAR_PROJECT:-$HOME/Documents/DTRA_Start/DTRA}"
PY="$ROOT/.venv/bin/python"; [ -x "$PY" ] || PY=python3
HERE="$(cd "$(dirname "$0")" && pwd)"
OUT="$ROOT/artifacts/variel_final_code_freeze_v10"
mkdir -p "$OUT" "$ROOT/artifacts/logs"

echo "V10_PREFLIGHT_BEGIN"
N=$(find "$ROOT/artifacts/variel_cross_backbone_all_final/endpoint_cache" -maxdepth 1 -name '*.pkl.gz' 2>/dev/null | wc -l)
echo "endpoint_caches=$N expected=200"
[ "$N" -eq 200 ] || { echo "ERROR expected 200 frozen endpoint caches"; exit 2; }

for f in \
  VARIEL_OCCUPANCY_LTT_TERMINAL_v9_Review.zip \
  VARIEL_CROSS_BACKBONE_ALL_FINAL_Review.zip \
  VARIEL_COMPASS_INDEPENDENT_FINAL_Review.zip \
  VARIEL_COMPASS_SR_FINAL_Review.zip \
  VARIEL_vs_UPF_Review.zip \
  VARIEL_vs_SeverityAware_Review.zip \
  VARIEL_Final_80of80_Evidence_Review.zip
do
  [ -f "$ROOT/$f" ] || { echo "ERROR missing $ROOT/$f"; exit 3; }
done
echo "V10_PREFLIGHT_OK"

"$PY" -u "$HERE/multiclass_ltt_closure.py" | tee "$ROOT/artifacts/logs/final_v10_ltt_mc.log"
"$PY" -u "$HERE/runtime_compute_closure.py" | tee "$ROOT/artifacts/logs/final_v10_runtime.log"
"$PY" -u "$HERE/finalize_code_freeze.py" | tee "$ROOT/artifacts/logs/final_v10_finalize.log"
