# VARIEL Final Code-Freeze Closure v10

This is the last quantitative/programming closure after the frozen V9 720/720 result.

It does **no backbone training** and does not alter any frozen result.

## A. Multiclass LTT-MC

Scope:
- Gas
- Rialto
- INSECTS
- BLE RSSI
- CatBoost + FT-Transformer
- 10 seeds each = 80 paired cells

The comparator is a deliberately conservative multiclass Learn-Then-Test
instantiation over a **fixed temperature-scaling hypothesis family**.

- The hypotheses are fixed before target labels.
- The existing 5% canaries are used only for hypothesis testing.
- Multiclass Brier paired differences are bounded in [-2,2].
- One-sided Hoeffding p-values are Holm-corrected within each window.
- If nothing is certified, LTT-MC selects STATIC.
- Audited canary predictions remain raw.
- No future labels and no target-label model fitting are used.

This is explicitly an LTT-MC sensitivity extension, **not** a claim that the
original binary MCGrad/LTT authors published this exact multiclass benchmark.

## B. Runtime / compute closure

The collector separates three quantities that must not be conflated:

1. **Controller / decision overhead** — directly matched on the completed
   80 dataset-seed whole-system run against UPF and Severity-Aware.
2. **Training / endpoint generation** — expensive research-model construction.
3. **Total end-to-end wall clock** — training + decision.

The already-recorded evidence indicates a strong controller-efficiency result:
VARIEL decision overhead was faster on all 80 seeds against both UPF and
Severity-Aware. The script recomputes this from the review ZIPs.

It does **not** turn that result into a false claim of universal end-to-end
runtime superiority.

## Run

```bash
cd ~/Documents/DTRA_Start/DTRA
rm -rf VARIEL_FINAL_CODE_FREEZE_v10
unzip -o VARIEL_FINAL_CODE_FREEZE_v10.zip -d VARIEL_FINAL_CODE_FREEZE_v10
cd VARIEL_FINAL_CODE_FREEZE_v10

bash run_all.sh
```

No GPU is required. This should be a post-processing run over the existing
200 frozen endpoint caches.

Monitor the LTT-MC part:

```bash
tail -F ~/Documents/DTRA_Start/DTRA/artifacts/logs/final_v10_ltt_mc.log
```

Final output:

`~/Documents/DTRA_Start/DTRA/VARIEL_FINAL_CODE_FREEZE_v10_Review.zip`

Ideal terminal line:

`FINAL_CODE_FREEZE_COMPLETE ...`

and in `FINAL_CODE_FREEZE_ASSESSMENT.json`:

`"code_freeze_ready": true`
