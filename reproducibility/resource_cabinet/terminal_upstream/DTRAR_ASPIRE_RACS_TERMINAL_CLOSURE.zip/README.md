# RACS Terminal Development Closure

RACS = Regime-Adaptive Consensus Shrinkage.

It activates only for the 21 states that remained unresolved after
SHARP + CPPI-GREG.

No new labels and no model retraining are required.

```math
mu_RACS = (3/8) mu_CPPI + (5/8) mu_SHARP
```

The weight is selected from a coarse rational grid using cross-domain
development performance.  The same frozen weight is then audited separately
on Bank, Electricity, Gas, and Spam hard-state blocks.

Important: this closes the **six-domain development operational-regret gate**.
It is not a replacement for a fresh frozen external validation, and it does
not turn the 21 rescue rows into new individual frequentist confidence
intervals.

## Run

```bash
bash run.sh
```

This is CSV-only and completes in seconds.
