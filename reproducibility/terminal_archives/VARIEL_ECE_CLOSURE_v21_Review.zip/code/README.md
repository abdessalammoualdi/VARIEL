# VARIEL ECE Closure v21

Final targeted calibration closure over V20.

No backbone retraining. Only the four V20 main cells with negative mean ECE are
recomputed (40 seed jobs).

Binary cells use cumulative historical-canary Beta calibration. Rialto uses
temperature + shrunken prior correction. The current window canaries only
select/fallback among candidates; those canary outputs themselves remain
unchanged after labels are observed.

All V20 cells that already pass remain untouched.

Run:

```bash
cd ~/Documents/DTRA_Start/DTRA
rm -rf VARIEL_ECE_CLOSURE_v21
unzip -o VARIEL_ECE_CLOSURE_v21.zip -d VARIEL_ECE_CLOSURE_v21
cd VARIEL_ECE_CLOSURE_v21

nohup setsid env V21_WORKERS=4 bash run.sh </dev/null \
  > ~/Documents/DTRA_Start/DTRA/artifacts/logs/v21.log 2>&1 & echo "V21_PID=$!"
```

Monitor:

```bash
tail -F ~/Documents/DTRA_Start/DTRA/artifacts/logs/v21.log
```

Progress:

```bash
watch -n 10 'LOG="$HOME/Documents/DTRA_Start/DTRA/artifacts/logs/v21.log"; echo -n "V21: "; grep -c "^V21_DONE" "$LOG"; echo " / 40"; grep -E "V21_TARGETS|V21_COMPLETE|Traceback|ERROR" "$LOG" | tail -8'
```

Final:
`~/Documents/DTRA_Start/DTRA/VARIEL_ECE_CLOSURE_v21_Review.zip`
