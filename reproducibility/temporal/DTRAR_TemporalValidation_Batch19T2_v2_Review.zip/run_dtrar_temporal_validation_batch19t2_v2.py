#!/usr/bin/env python3
"""
Batch19T2-v2 — additional prospectively locked temporal confirmation.

Outdoor Objects was rejected BEFORE any performance was computed because the
first 30% chronological source segment did not contain target class '13'.
Therefore the original T2 run opened no Spam or Outdoor performance and remains
clean.

Replacement selected on protocol fit only:
  * Spam real-world drift stream.
  * UCI Ozone Level Detection (eighthr.data): sequential/time-series
    classification collected from 1998–2004.

Three-stage evidence protocol
-----------------------------
1) Structural eligibility + immutable lock.
2) Blind execution of the byte-frozen 5% router.
3) Immutable disclosure + synthesis.

No method changes, no tuning, no dataset-specific performance selection.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
import hashlib, importlib.util, io, json, math, shutil, sys, urllib.request, zipfile

import numpy as np
import pandas as pd
from sklearn.impute import SimpleImputer
from threadpoolctl import threadpool_limits

PROJECT = Path(__file__).resolve().parent
OUT = PROJECT/"artifacts"/"dtrar_temporal_validation_batch19t2_v2"
OUT.mkdir(parents=True, exist_ok=True)

FROZEN_SHA = "6364bbbb2e3890ee5f06c62993b972bd4e8f1bd402d0ed5d74070e9f40bcda8e"
SEEDS = list(range(10))
BUDGET = 0.05
SOURCE_FRACTION = 0.30
TARGET_WINDOWS = 14

DATASETS = {
    "spam": {
        "kind":"csv_last_label",
        "url":"https://raw.githubusercontent.com/ogozuacik/concept-drift-datasets-scikit-multiflow/master/real-world/spam.csv",
        "expected_rows":6213,
        "row_tolerance":3,
        "expected_features":499,
        "expected_classes":2,
        "provenance":"Real-world Spam concept-drift stream distributed in the scikit-multiflow drift benchmark collection."
    },
    "ozone": {
        "kind":"uci_ozone_zip",
        "url":"https://archive.ics.uci.edu/static/public/172/ozone%2Blevel%2Bdetection.zip",
        "member":"eighthr.data",
        "expected_rows_min":2500,
        "expected_rows_max":2600,
        "expected_features":72,
        "expected_classes":2,
        "doi":"10.24432/C5NG6W",
        "provenance":"UCI Ozone Level Detection; multivariate sequential/time-series classification collected in Houston/Galveston/Brazoria from 1998–2004."
    },
}

def must(c,m):
    if not c:
        raise RuntimeError(m)

def sha256(path):
    h=hashlib.sha256()
    with open(path,"rb") as f:
        for b in iter(lambda:f.read(1<<20),b""):
            h.update(b)
    return h.hexdigest()

def download(url,path):
    path.parent.mkdir(parents=True,exist_ok=True)
    if path.exists() and path.stat().st_size>1000:
        return
    print(f"T2V2_DOWNLOAD_BEGIN url={url}",flush=True)
    req=urllib.request.Request(url,headers={"User-Agent":"Mozilla/5.0"})
    with urllib.request.urlopen(req,timeout=240) as r, open(path,"wb") as f:
        shutil.copyfileobj(r,f)
    print(f"T2V2_DOWNLOAD_COMPLETE file={path} bytes={path.stat().st_size}",flush=True)

def import_local(name,path):
    spec=importlib.util.spec_from_file_location(name,path)
    must(spec and spec.loader,f"cannot import {path}")
    mod=importlib.util.module_from_spec(spec)
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod

must(sha256(PROJECT/"frozen_sparse_router_source.py")==FROZEN_SHA,
     "frozen router source hash mismatch")
fr=import_local("frozen_sparse_router_source",PROJECT/"frozen_sparse_router_source.py")
import run_dtrar_risk_optimal_final as ro

@dataclass
class Dataset:
    name:str
    X:np.ndarray
    y:np.ndarray
    train:np.ndarray
    source:np.ndarray
    windows:list
    classes:list
    @property
    def target(self):
        return np.concatenate(self.windows)

def primary_cfg():
    p=PROJECT/"offset_check_v07"/"configs"/"primary.json"
    if p.exists():
        return json.loads(p.read_text())
    return {"tree_rounds":800,"tree_depth":6,"tree_learning_rate":0.05,"tree_early_stopping":50}

def load_spam_raw(path):
    df=pd.read_csv(path)
    df=df.loc[:,[c for c in df.columns if not str(c).lower().startswith("unnamed:")]]
    must(df.shape[1]==500,f"spam: expected 500 columns incl label, got {df.shape[1]}")
    X=df.iloc[:,:-1].apply(pd.to_numeric,errors="coerce").to_numpy(np.float32)
    yraw=df.iloc[:,-1].astype(str).to_numpy()
    return X,yraw

def extract_ozone_member(zip_path,member):
    with zipfile.ZipFile(zip_path) as z:
        names=z.namelist()
        hits=[n for n in names if n.lower().endswith(member.lower())]
        must(len(hits)>=1,f"ozone archive missing {member}")
        data=z.read(sorted(hits,key=len)[0])
    # date + 72 features + target = 74 columns
    df=pd.read_csv(io.BytesIO(data),header=None,na_values=["?"],engine="python")
    df=df.dropna(how="all").reset_index(drop=True)
    must(73 <= df.shape[1] <= 74,f"ozone: unexpected columns {df.shape[1]}")
    # UCI ozone format is date, 72 features, class. If date is absent, handle 73 cols.
    if df.shape[1]==74:
        Xdf=df.iloc[:,1:-1]
    else:
        Xdf=df.iloc[:,:-1]
    must(Xdf.shape[1]==72,f"ozone: expected 72 features, got {Xdf.shape[1]}")
    X=Xdf.apply(pd.to_numeric,errors="coerce").to_numpy(np.float32)
    yraw=df.iloc[:,-1].astype(str).str.strip().to_numpy()
    return X,yraw

def load_raw(name,path,spec):
    if spec["kind"]=="csv_last_label":
        return load_spam_raw(path)
    if spec["kind"]=="uci_ozone_zip":
        return extract_ozone_member(path,spec["member"])
    raise ValueError(spec["kind"])

def structural_audit(name,path,spec):
    X,yraw=load_raw(name,path,spec)
    n=len(yraw)
    if "expected_rows" in spec:
        must(abs(n-spec["expected_rows"])<=spec["row_tolerance"],
             f"{name}: row count {n} != expected ~{spec['expected_rows']}")
    else:
        must(spec["expected_rows_min"]<=n<=spec["expected_rows_max"],
             f"{name}: row count {n} outside expected range")
    must(X.shape[1]==spec["expected_features"],f"{name}: feature count {X.shape[1]}")
    classes=sorted(pd.unique(yraw).tolist())
    must(len(classes)==spec["expected_classes"],
         f"{name}: class count {len(classes)} != {spec['expected_classes']}")
    source_n=int(math.floor(SOURCE_FRACTION*n))
    src=set(yraw[:source_n].tolist())
    tgt=set(yraw[source_n:].tolist())
    unseen=sorted(tgt-src)
    return {
        "rows":n,
        "features":int(X.shape[1]),
        "all_classes":len(classes),
        "source_rows":source_n,
        "target_rows":n-source_n,
        "source_classes":len(src),
        "target_classes":len(tgt),
        "unseen_target_classes":unseen,
        "closed_set_eligible":len(unseen)==0,
    }

def parse_after_lock(name,path,spec):
    X,yraw=load_raw(name,path,spec)
    labels=sorted(pd.unique(yraw).tolist())
    mp={v:i for i,v in enumerate(labels)}
    y=np.asarray([mp[v] for v in yraw],int)
    n=len(y)
    source_n=int(math.floor(SOURCE_FRACTION*n))
    source=np.arange(source_n,dtype=int)
    target=np.arange(source_n,n,dtype=int)
    windows=[np.asarray(x,dtype=int) for x in np.array_split(target,TARGET_WINDOWS) if len(x)]
    must(len(windows)==TARGET_WINDOWS,f"{name}: expected {TARGET_WINDOWS} windows")
    return Dataset(name,X,y,source.copy(),source.copy(),windows,[str(v) for v in labels])

def source_fit(data):
    vals=ro.core.monitoring_roles(data.source,data.y)
    return np.asarray(vals[0],int)

def train_xgb(data,seed,file_sha):
    from xgboost import XGBClassifier
    cache=OUT/"models"/data.name/f"seed_{seed}"
    cache.mkdir(parents=True,exist_ok=True)
    pf=cache/"probabilities.npz"; meta=cache/"COMPLETE.json"
    if pf.exists() and meta.exists():
        m=json.loads(meta.read_text())
        if m.get("file_sha256")==file_sha and m.get("protocol")=="chronological_30_70_14windows":
            with np.load(pf) as z:
                return np.asarray(z["probabilities"],float)
    cfg=primary_cfg()
    tr=np.asarray(data.train,int)
    boundary=max(1,int(math.floor(.8*len(tr))))
    inner=tr[:boundary]; valid=tr[boundary:]
    if len(valid)==0:
        valid=inner[-max(1,len(inner)//5):]
        inner=inner[:-len(valid)]
    imp=SimpleImputer(strategy="median").fit(data.X[inner])
    Xin=imp.transform(data.X[inner]).astype(np.float32)
    Xva=imp.transform(data.X[valid]).astype(np.float32)
    k=len(data.classes)
    args=dict(
        n_estimators=int(cfg.get("tree_rounds",800)),
        max_depth=int(cfg.get("tree_depth",6)),
        learning_rate=float(cfg.get("tree_learning_rate",.05)),
        subsample=.9,colsample_bytree=.9,min_child_weight=2,reg_lambda=1.,
        tree_method="hist",n_jobs=1,random_state=seed,
        objective="binary:logistic" if k==2 else "multi:softprob",
        eval_metric="logloss" if k==2 else "mlogloss",
    )
    sel=XGBClassifier(**args,early_stopping_rounds=int(cfg.get("tree_early_stopping",50)))
    sel.fit(Xin,data.y[inner],eval_set=[(Xva,data.y[valid])],verbose=False)
    rounds=max(1,int(getattr(sel,"best_iteration",args["n_estimators"]-1))+1)
    fullimp=SimpleImputer(strategy="median").fit(data.X[tr])
    Xall=fullimp.transform(data.X).astype(np.float32)
    args["n_estimators"]=rounds
    mdl=XGBClassifier(**args)
    mdl.fit(Xall[tr],data.y[tr],verbose=False)
    raw=np.asarray(mdl.predict_proba(Xall),float)
    must(raw.shape[1]==k,f"{data.name}: predicted {raw.shape[1]} classes, expected {k}")
    np.savez_compressed(pf,probabilities=raw,row_id=np.arange(len(data.y)))
    meta.write_text(json.dumps({
        "file_sha256":file_sha,"seed":seed,"rounds":rounds,
        "protocol":"chronological_30_70_14windows"
    },indent=2))
    return raw

def run_router(name,seed,data,raw,sf):
    old_ld=fr.load_dataset; old_lr=fr.load_historical_raw; old_b=fr.TOTAL_BUDGET
    try:
        fr.TOTAL_BUDGET=BUDGET
        fr.load_dataset=lambda n,p:data
        fr.load_historical_raw=lambda n,s,d:(raw,sf,np.array([],int),None,{})
        return fr.run_seed(name,seed)
    finally:
        fr.load_dataset=old_ld
        fr.load_historical_raw=old_lr
        fr.TOTAL_BUDGET=old_b

def main():
    rawdir=OUT/"raw"; rawdir.mkdir(parents=True,exist_ok=True)
    local_paths={}
    rawmeta={}
    structural={}

    # Stage 1: download + structural eligibility, no model performance.
    for name,spec in DATASETS.items():
        ext=".zip" if spec["kind"]=="uci_ozone_zip" else ".csv"
        p=rawdir/f"{name}{ext}"
        download(spec["url"],p)
        local_paths[name]=p
        rawmeta[name]={**spec,"local_file":str(p),"sha256":sha256(p),"bytes":p.stat().st_size}
        structural[name]=structural_audit(name,p,spec)

    stage1={
        "stage":"1_structural_eligibility_and_lock",
        "outdoor_prior_status":"rejected pre-performance because deployment introduced unseen class 13",
        "replacement_basis":"Ozone selected for temporal/sequential protocol fit before any model outcome",
        "method_sha256":FROZEN_SHA,
        "budget":BUDGET,
        "source_fraction":SOURCE_FRACTION,
        "target_fraction":1-SOURCE_FRACTION,
        "target_windows":TARGET_WINDOWS,
        "seeds":SEEDS,
        "no_dataset_removal_after_performance":True,
        "datasets":rawmeta,
        "structural_audit":structural,
    }
    (OUT/"T2V2_STAGE1_ELIGIBILITY_LOCK.json").write_text(json.dumps(stage1,indent=2,sort_keys=True))
    for name,a in structural.items():
        must(a["closed_set_eligible"],
             f"{name}: structural eligibility failed BEFORE performance; unseen target classes={a['unseen_target_classes']}")
    print("T2V2_STAGE1_LOCK_COMPLETE all_structurally_eligible=true performance_not_run=true",flush=True)

    # Stage 2: blind execution.
    rows=[];job=0
    with threadpool_limits(limits=1):
        for name,spec in DATASETS.items():
            data=parse_after_lock(name,local_paths[name],spec)
            sf=source_fit(data)
            for seed in SEEDS:
                job+=1
                raw=train_xgb(data,seed,rawmeta[name]["sha256"])
                s,_=run_router(name,seed,data,raw,sf)
                final=float(s.get("final_brier",s.get("router_brier")))
                gain=float(s["raw_brier"]-final)
                rows.append({
                    "dataset":name,"seed":seed,
                    "raw_brier":float(s["raw_brier"]),
                    "router_brier":final,
                    "gain":gain,
                    "relative_reduction":gain/float(s["raw_brier"]),
                    "max_exact_H":float(s.get("max_exact_H",np.nan)),
                    "label_fraction":float(s.get("label_fraction",np.nan)),
                })
                print(f"T2V2_CONFIRM {job}/20 dataset={name} seed={seed} raw={s['raw_brier']:.9f} router={final:.9f} gain={gain:.9f}",flush=True)

    df=pd.DataFrame(rows)
    df.to_csv(OUT/"T2V2_TEMPORAL_SEEDWISE.csv",index=False)
    sm=df.groupby("dataset").agg(
        mean_raw_brier=("raw_brier","mean"),
        mean_router_brier=("router_brier","mean"),
        mean_gain=("gain","mean"),
        min_seed_gain=("gain","min"),
        positive_seeds=("gain",lambda x:int((x>0).sum())),
        max_exact_H=("max_exact_H","max"),
        mean_label_fraction=("label_fraction","mean"),
    ).reset_index()
    sm["relative_reduction"]=sm.mean_gain/sm.mean_raw_brier
    sm["ten_of_ten_positive"]=sm.positive_seeds.eq(10)
    sm.to_csv(OUT/"T2V2_TEMPORAL_SUMMARY.csv",index=False)

    # Stage 3: preserve prior evidence and consolidate.
    prior=pd.read_csv(PROJECT/"REF_WEATHER_RIALTO_SUMMARY.csv")
    prior["evidence_block"]="Batch19T prospectively locked"
    current=sm.copy()
    current["evidence_block"]="Batch19T2-v2 prospectively locked"
    common=["dataset","mean_raw_brier","mean_router_brier","mean_gain","relative_reduction","positive_seeds","evidence_block"]
    consolidated=pd.concat([prior[common],current[common]],ignore_index=True)
    consolidated["ten_of_ten_positive"]=consolidated.positive_seeds.eq(10)
    consolidated.to_csv(OUT/"CONSOLIDATED_TEMPORAL_HOLDOUTS.csv",index=False)

    assessment={
        "method_changed":False,
        "outdoor_performance_ever_opened":False,
        "outdoor_replaced_after_structural_ineligibility_only":True,
        "spam_ozone_each_mean_positive":bool((sm.mean_gain>0).all()),
        "spam_ozone_each_10of10":bool(sm.ten_of_ten_positive.all()),
        "all_four_temporal_mean_positive":bool((consolidated.mean_gain>0).all()),
        "all_four_temporal_at_least_8of10":bool((consolidated.positive_seeds>=8).all()),
        "number_of_10of10_temporal_streams":int(consolidated.ten_of_ten_positive.sum()),
        "weather_rialto_preserved":True,
        "har_hapt_preserved_as_stress_tests":True,
        "stop_rule":"No method changes after these results; report every locked eligible stream."
    }
    (OUT/"T2V2_FINAL_ASSESSMENT.json").write_text(json.dumps(assessment,indent=2,sort_keys=True))

    review=PROJECT/"DTRAR_TemporalValidation_Batch19T2_v2_Review.zip"
    with zipfile.ZipFile(review,"w",zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.rglob("*")):
            if p.is_file():
                z.write(p,str(p.relative_to(OUT)))
        z.write(Path(__file__),Path(__file__).name)
        z.write(PROJECT/"frozen_sparse_router_source.py","frozen_sparse_router_source.py")
        z.write(PROJECT/"REF_WEATHER_RIALTO_SUMMARY.csv","REF_WEATHER_RIALTO_SUMMARY.csv")
        z.write(PROJECT/"REF_HAR_HAPT_STRESS_TEST_SUMMARY.csv","REF_HAR_HAPT_STRESS_TEST_SUMMARY.csv")

    print("\n=== T2V2 SUMMARY ===")
    print(sm.to_string(index=False))
    print("\n=== T2V2 FINAL ASSESSMENT ===")
    print(json.dumps(assessment,indent=2,sort_keys=True))
    print(f"TEMPORAL_VALIDATION_BATCH19T2_V2_COMPLETE review={review.name}",flush=True)

if __name__=="__main__":
    main()
