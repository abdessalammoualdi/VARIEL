#!/usr/bin/env python3
"""
DTRAR 5% Shared-Stream Current-Utility Expert Router — development probe

One fixed architecture. No budget sweep, no epsilon sweep, no fresh holdouts.

Core idea
---------
Use one honest 5% target-label stream:
  * 20% of the budget (~1% of target) = immediate current-window geometry canaries
  * 80% of the budget (~4% of target) = random learner labels for future windows

From the SAME observed label history, construct several support-residual repair
states ("drawers"):

  raw          : no repair
  thin40       : support-residual fitted on a nested 40% view of target history
  mid60        : support-residual fitted on a nested 60% view
  full100      : support-residual fitted on all probability-role target history
  reuse100     : support-residual fitted on all target history (target reuse)

The 40/60/100 history fractions are fixed before the experiment and correspond
to the historical 2%/3%/5% budget ratios. They do NOT consume separate label
streams: all experts are views of the same <=5% observed labels.

Before current labels:
  1. freeze all candidate probability maps;
  2. select current canaries from unlabeled multi-expert repair geometry.

After current canary labels:
  3. estimate each expert direction's current Brier utility;
  4. compute a simultaneous uncertainty penalty;
  5. choose raw or the expert with largest positive conservative gain;
  6. choose its plug-in risk-optimal interpolation eta = clip(D_hat/C,0,1);
  7. apply only to non-canary bulk;
  8. compute exact prospective Brier action liability H (diagnostic, not .02-clipped).

After action:
  9. current canaries enter future learning immediately;
 10. random learner labels enter future learning with one-window feedback delay.

The exact historical support-residual mathematics is embedded below from the
recovered Focus Review implementation:
  calibration.py SHA256 0f905520...
  residual_calibration.py SHA256 8c92bce...

This is development-only. Batch 17 and all fresh holdouts are untouched.
"""

from __future__ import annotations

from pathlib import Path
import hashlib
import json
import math
import zipfile

import numpy as np
import pandas as pd
from scipy.optimize import minimize
from scipy.special import expit, logsumexp
from threadpoolctl import threadpool_limits

import dtrar_final_core as fc
from dtra.data import load_dataset

PROJECT = Path(__file__).resolve().parent
OUT = PROJECT / "artifacts" / "dtrar_expert_router_5pct_plugin_router"

DATASETS = ["bank", "electricity", "gas"]
SEEDS = list(range(10))

TOTAL_BUDGET = 0.05
CANARY_BUDGET_SHARE = 0.20
LEARNER_BUDGET_SHARE = 0.80
DELAY = 1
BUFFER_WINDOWS = 3
DECAY = 0.9
SOURCE_MASS = 0.1
CALIBRATOR_PENALTY = 0.001
MAX_STRATA = 8

# Simultaneous router confidence. Fixed before the run.
ROUTER_ALPHA = 0.10

# Nested history fractions. These are not separate label budgets.
EXPERTS = {
    "thin40": {"history_fraction": 0.40, "reuse": False},
    "mid60":  {"history_fraction": 0.60, "reuse": False},
    "full100":{"history_fraction": 1.00, "reuse": False},
    "reuse100":{"history_fraction": 1.00, "reuse": True},
}

# Strongest sparse/equal-information development references already observed.
SPARSE_REFERENCE = {
    "bank": 0.371192,         # historical simple_target_reuse, 5%
    "electricity": 0.35732846443581634,  # frozen DTRAR
    "gas": 0.628178,          # historical simple_periodic_02, 2%
}
HISTORICAL_PERIODIC = {
    "bank": {"p02":0.380567, "p03":0.374495, "p05":0.375047, "target_reuse":0.371192},
    "electricity": {"p02":0.394499, "p03":0.383170, "p05":0.389414, "target_reuse":0.388136},
    "gas": {"p02":0.628178, "p03":0.640944, "p05":0.648680, "target_reuse":0.674802},
}
FULL_FEEDBACK_REFERENCE = {
    "bank": 0.364310,
    "electricity": 0.365481,
    "gas": 0.585471,
}

FOCUS_SIGNATURE = "5c828cd0de3b"
FOCUS_ARM = "simple_periodic_05"
FOCUS_CONFIG_SUFFIX = "e7e464474b90"

def must(cond, msg):
    if not cond:
        raise RuntimeError(msg)

def probabilities(p):
    p = np.asarray(p, float)
    p = np.clip(p, 1e-12, np.inf)
    return p / p.sum(axis=1, keepdims=True)

def brier_rows(p, y):
    p = probabilities(p)
    y = np.asarray(y, int)
    truth = np.eye(p.shape[1])[y]
    return np.sum((p-truth)**2, axis=1)

# ---------------------------------------------------------------------------
# Exact historical probability calibration primitives
# ---------------------------------------------------------------------------

class ProbabilityCalibrator:
    """Recovered historical monotone-beta / regularized-Dirichlet calibrator."""
    def __init__(self, penalty=.001):
        self.penalty = float(penalty)

    def fit(self, p, y, sample_weight=None):
        p = probabilities(p)
        y = np.asarray(y, int)
        self.k = p.shape[1]
        w = np.ones(len(y), float) if sample_weight is None else np.asarray(sample_weight, float)
        if len(y) != len(p) or np.any(w < 0) or not np.isfinite(w).all() or w.sum() <= 0:
            raise ValueError("Invalid calibration data")
        w = w / w.sum()

        if self.k == 2:
            self.kind = "monotone_beta"
            design = np.column_stack([np.log(p[:,1]), -np.log(p[:,0]), np.ones(len(p))])
            initial = np.array([1.,1.,0.])
            def objective(theta):
                z = design @ theta
                loss = np.sum(w * (np.logaddexp(0.,z) - y*z))
                grad = design.T @ (w*(expit(z)-y))
                delta = theta-initial
                return loss+self.penalty*np.dot(delta,delta), grad+2*self.penalty*delta
            result = minimize(objective, initial, jac=True, bounds=[(1e-8,None),(1e-8,None),(None,None)],
                              method="L-BFGS-B", options={"maxiter":1500,"ftol":1e-12})
        else:
            self.kind = "regularized_dirichlet"
            design = np.log(p)
            target = np.eye(self.k)[y]
            initial = np.r_[np.eye(self.k).ravel(), np.zeros(self.k)]
            def objective(theta):
                matrix = theta[:self.k**2].reshape(self.k,self.k)
                offset = theta[self.k**2:]
                logits = design @ matrix.T + offset
                lp = logits-logsumexp(logits,axis=1,keepdims=True)
                err = w[:,None]*(np.exp(lp)-target)
                delta = theta-initial
                loss = -np.sum(w*lp[np.arange(len(y)),y])+self.penalty*np.dot(delta,delta)
                grad = np.r_[(err.T@design).ravel(),err.sum(axis=0)] + 2*self.penalty*delta
                return loss,grad
            result = minimize(objective, initial, jac=True, method="L-BFGS-B",
                              options={"maxiter":1500,"ftol":1e-12})
        if not result.success or not np.isfinite(result.fun):
            raise RuntimeError(f"Source calibration failed: {result.message}")
        self.theta = result.x
        return self

    def predict_proba(self, p):
        p = probabilities(p)
        if self.k == 2:
            design = np.column_stack([np.log(p[:,1]), -np.log(p[:,0]), np.ones(len(p))])
            q = expit(design@self.theta)
            return probabilities(np.column_stack([1-q,q]))
        matrix = self.theta[:self.k**2].reshape(self.k,self.k)
        offset = self.theta[self.k**2:]
        scores = np.log(p)@matrix.T+offset
        return probabilities(np.exp(scores-logsumexp(scores,axis=1,keepdims=True)))


class ResidualCalibration:
    """Byte-faithful mathematics of recovered support_residual calibration."""
    def __init__(self, source_calibrator, family, target_effective_size, penalty=.001):
        self.source_calibrator = source_calibrator
        self.family = family
        self.target_effective_size = float(target_effective_size)
        self.penalty = float(penalty)

    def fit(self, p, y, sample_weight):
        p = self.source_calibrator.predict_proba(p)
        y = np.asarray(y,int)
        w = np.asarray(sample_weight,float)
        if len(y)!=len(p) or np.any(w<0) or not np.isfinite(w).all() or w.sum()<=0:
            raise ValueError("Invalid residual calibration data")
        w = w/w.sum()
        self.k = p.shape[1]
        z = np.log(probabilities(p))
        use_offsets = self.family=="support_residual"
        if not use_offsets and self.family!="temperature":
            raise ValueError(self.family)
        offset_penalty = (self.k-1)/max(self.target_effective_size,1.)
        initial = np.r_[1.,np.zeros(self.k)] if use_offsets else np.ones(1)
        truth = np.eye(self.k)[y]
        def objective(theta):
            scores = theta[0]*z
            if use_offsets:
                scores = scores+theta[1:]
            lp = scores-logsumexp(scores,axis=1,keepdims=True)
            error = w[:,None]*(np.exp(lp)-truth)
            loss = -np.sum(w*lp[np.arange(len(y)),y])+self.penalty*(theta[0]-1)**2
            grad = [np.sum(error*z)+2*self.penalty*(theta[0]-1)]
            if use_offsets:
                loss += offset_penalty*np.dot(theta[1:],theta[1:])
                grad.extend(error.sum(axis=0)+2*offset_penalty*theta[1:])
            return loss,np.asarray(grad)
        bounds=[(1e-8,None)]+([(None,None)]*self.k if use_offsets else [])
        result=minimize(objective,initial,jac=True,bounds=bounds,method="L-BFGS-B",
                        options={"maxiter":1500,"ftol":1e-12})
        if not result.success or not np.isfinite(result.fun):
            raise RuntimeError(f"Residual calibration failed: {result.message}")
        self.theta=result.x
        self.fit_info={
            "kind":self.family,
            "n":len(y),
            "target_effective_size":self.target_effective_size,
            "inverse_temperature":float(self.theta[0]),
            "offsets":self.theta[1:].tolist(),
            "offset_penalty":float(offset_penalty),
            "objective":float(result.fun),
        }
        return self

    def predict_proba(self,p):
        scores=self.theta[0]*np.log(probabilities(self.source_calibrator.predict_proba(p)))
        if self.family=="support_residual":
            scores += self.theta[1:]
        return probabilities(np.exp(scores-logsumexp(scores,axis=1,keepdims=True)))

# ---------------------------------------------------------------------------
# Utilities
# ---------------------------------------------------------------------------

def stable_seed(*parts):
    raw="|".join(map(str,parts)).encode()
    return int.from_bytes(hashlib.sha256(raw).digest()[:8],"little")%(2**32-1)

def allocate(total, capacities, masses=None):
    capacities=np.asarray(capacities,int)
    if total<=0:
        return np.zeros(len(capacities),int)
    total=min(int(total),int(capacities.sum()))
    if masses is None:
        masses=capacities.astype(float)
    masses=np.asarray(masses,float)
    active=capacities>0
    out=np.zeros(len(capacities),int)
    remaining=total
    while remaining>0 and np.any(out<capacities):
        eligible=(out<capacities)&active
        w=np.where(eligible,masses,0.)
        if w.sum()<=0:
            w=eligible.astype(float)
        quota=remaining*w/w.sum()
        floor=np.minimum(np.floor(quota).astype(int), capacities-out)
        if floor.sum()>0:
            out+=floor
            remaining-=int(floor.sum())
            continue
        frac=quota-np.floor(quota)
        order=np.argsort(-frac)
        moved=False
        for i in order:
            if eligible[i] and out[i]<capacities[i]:
                out[i]+=1; remaining-=1; moved=True
                if remaining==0: break
        if not moved: break
    must(out.sum()==total,"allocation failure")
    return out

def locate_focus_job(dataset,seed):
    base=PROJECT/"focus_v05"/"artifacts"/"focus_after_primary"/FOCUS_SIGNATURE/"jobs"/f"{dataset}_seed{seed}_{FOCUS_ARM}"
    must(base.exists(),f"historical Focus job missing: {base}")
    matches=list((base/dataset/"xgboost").glob(f"seed_{seed}_primary_*_{FOCUS_CONFIG_SUFFIX}"))
    must(len(matches)==1,f"expected one historical 5% Focus result, found {len(matches)} for {dataset} seed {seed}")
    return matches[0]

def load_historical_raw(dataset,seed,data):
    run=locate_focus_job(dataset,seed)
    cfg=json.loads((run/"configuration.json").read_text())
    cache=Path(cfg["frozen_model_cache"])
    if not cache.exists():
        # Recover relative historical cache location under this project.
        suffix=Path(*cache.parts[-5:])
        alt=PROJECT/suffix
        if alt.exists(): cache=alt
        else:
            candidates=list((PROJECT/"focus_v05"/"artifacts"/"models"/dataset/"xgboost").glob(f"seed_{seed}_primary_*"))
            must(len(candidates)==1,f"cannot locate historical frozen model cache for {dataset} seed {seed}")
            cache=candidates[0]
    with np.load(cache/"frozen_probabilities.npz") as z:
        row_id=np.asarray(z["row_id"],int)
        raw=probabilities(z["probabilities"])
    must(np.array_equal(row_id,np.arange(len(data.y))),"historical cache row IDs mismatch")
    with np.load(run/"source_roles.npz") as z:
        source_fit=np.asarray(z["probability_fit"],int)
        score_fit=np.asarray(z["score_fit"],int)
    return raw,source_fit,score_fit,run,cfg

def target_roles(windows,seed,n):
    roles=np.full(n,-1,int)
    rng=np.random.default_rng(np.random.SeedSequence([seed,7601]))
    for ix in windows:
        ix=np.asarray(ix,int)
        shuffled=rng.permutation(ix)
        boundary=max(1,min(len(ix)-1,math.floor(len(ix)*0.5)))
        roles[shuffled[:boundary]]=0
        roles[shuffled[boundary:]]=1
    return roles

def budget_schedule(windows):
    n=int(sum(len(ix) for ix in windows))
    ceiling=int(math.floor(TOTAL_BUDGET*n))
    canary_total=int(math.floor(CANARY_BUDGET_SHARE*ceiling))
    learner_total=ceiling-canary_total
    can_counts=allocate(canary_total,[len(ix) for ix in windows],[len(ix) for ix in windows])
    useful=max(0,len(windows)-1-DELAY)
    capacities=[max(0,len(windows[t])-can_counts[t]) if t<useful else 0 for t in range(len(windows))]
    learn_counts=allocate(learner_total,capacities,[len(windows[t]) if t<useful else 0 for t in range(len(windows))])
    must(int(can_counts.sum()+learn_counts.sum())==ceiling,"budget schedule mismatch")
    return can_counts,learn_counts,ceiling

def nested_subset(items,fraction,seed,origin):
    if fraction>=1.0 or len(items)<=1:
        return list(items)
    scored=[]
    for item in items:
        key=stable_seed("history_nested",seed,origin,item["row_id"])
        scored.append((key,item))
    scored.sort(key=lambda x:x[0])
    count=max(1,int(math.ceil(fraction*len(scored))))
    return [x[1] for x in scored[:count]]

def fit_candidate(raw,y,source_fit,source_cal,roles,cohorts,clock,seed,history_fraction,reuse):
    fit_ids=list(map(int,source_fit))
    fit_y=[int(y[i]) for i in source_fit]
    weights=[SOURCE_MASS/max(1,len(source_fit))]*len(source_fit)

    recent=sorted([u for u,c in cohorts.items() if c["observed"]])[-BUFFER_WINDOWS:]
    target_weights=[]
    target_count=0
    for u in recent:
        c=cohorts[u]
        items=list(c["observed"])
        if not reuse:
            items=[it for it in items if roles[it["row_id"]]==0]
            population=int(np.sum(roles[np.asarray(c["indices"],int)]==0))
        else:
            population=len(c["indices"])
        if not items or population<=0:
            continue

        items=nested_subset(items,history_fraction,seed,u)
        decay=DECAY**max(0,clock-u)

        adaptive_arrived=any(it["kind"]=="learner" for it in c["observed"])
        for it in items:
            if adaptive_arrived:
                if it["kind"]=="canary":
                    w=1.0/population
                else:
                    w=1.0/(population*max(it["pi"],1e-12))
            else:
                w=len(c["indices"])/(max(1,c["canary_count"])*population)
            w*=decay
            fit_ids.append(int(it["row_id"]))
            fit_y.append(int(it["label"]))
            weights.append(float(w))
            target_weights.append(float(w))
            target_count+=1

    if target_count==0:
        return source_cal.predict_proba(raw), {
            "target_n":0,"target_effective_size":0.0,"kind":"source_only"
        }

    tw=np.asarray(target_weights,float)
    effective=float(tw.sum()**2/(tw@tw)) if (tw@tw)>0 else 0.0
    cal=ResidualCalibration(source_cal,"support_residual",effective,CALIBRATOR_PENALTY)
    cal.fit(raw[np.asarray(fit_ids,int)],np.asarray(fit_y,int),np.asarray(weights,float))
    return cal.predict_proba(raw), {
        "target_n":target_count,
        "target_effective_size":effective,
        **cal.fit_info,
    }

def expert_geometry(raw,candidates):
    # Multi-expert utility-range width, completely unlabeled.
    widths=[]
    for q in candidates.values():
        d=q-raw
        center=np.sum(raw*d,axis=1)
        z=d-center[:,None]
        widths.append(np.max(z,axis=1)-np.min(z,axis=1))
    return np.max(np.column_stack(widths),axis=1)

def canary_design(raw,candidates,m,rng):
    n=len(raw)
    m=min(max(0,int(m)),max(0,n-1))
    if m<=0:
        return [],np.array([],int),np.arange(n,dtype=int)

    width=expert_geometry(raw,candidates)
    H=min(MAX_STRATA,m,n)
    order=np.argsort(width,kind="mergesort")
    chunks=[np.asarray(x,int) for x in np.array_split(order,H) if len(x)]
    masses=[]
    for pop in chunks:
        masses.append(len(pop)*max(float(np.max(width[pop])),1e-12))
    counts=allocate(m,[len(x) for x in chunks],masses)

    strata=[]; chosen=[]
    for h,(pop,nh) in enumerate(zip(chunks,counts)):
        sample=np.sort(rng.choice(pop,size=int(nh),replace=False)) if nh else np.array([],int)
        chosen.extend(sample.tolist())
        strata.append({"h":h,"population":pop,"sample":sample})
    canary=np.sort(np.asarray(chosen,int))
    mask=np.ones(n,bool); mask[canary]=False
    bulk=np.flatnonzero(mask)
    return strata,canary,bulk

def estimate_candidate(raw,q,y_canary,strata,bulk,J):
    d=q-raw
    center=np.sum(raw*d,axis=1)
    z=d-center[:,None]
    M=max(1,len(bulk))
    D_hat=0.0
    radius_sum=0.0
    for st in strata:
        pop=st["population"]; samp=st["sample"]
        if len(samp)==0: continue
        vals=z[samp,y_canary[samp]]
        # Sample mean estimates the current stratum's unknown utility.
        mean=float(np.mean(vals))
        bulk_h=np.setdiff1d(pop,samp,assume_unique=True)
        Mh=len(bulk_h)
        D_hat += (Mh/M)*mean
        Rh=float(np.max(z[pop])-np.min(z[pop])) if len(pop) else 0.0
        radius_sum += ((len(pop)*Rh/M)**2)/len(samp)

    radius=math.sqrt(max(0.0,0.5*math.log(max(2.0,2.0*J/ROUTER_ALPHA))*radius_sum))
    if len(bulk):
        C=float(np.mean(np.sum(d[bulk]**2,axis=1)))
    else:
        C=0.0
    if C<=1e-18:
        eta=0.0
    else:
        eta=float(np.clip(D_hat/C,0.0,1.0))
    D_lower=D_hat-radius
    gain_hat=2*D_hat*eta-C*eta*eta
    gain_lower=2*D_lower*eta-C*eta*eta
    return {
        "D_hat":D_hat,"radius":radius,"D_lower":D_lower,"C":C,
        "eta":eta,"gain_hat":gain_hat,"gain_lower":gain_lower,
    }

def exact_H(raw,pred):
    return float(fc.prospective_H(raw,pred-raw))

def run_seed(dataset,seed):
    data=load_dataset(dataset,PROJECT/"data"/"raw")
    raw,source_fit,_,run_dir,cfg=load_historical_raw(dataset,seed,data)
    y=np.asarray(data.y,int)
    windows=[np.asarray(ix,int) for ix in data.windows]
    target=np.concatenate(windows)
    roles=target_roles(windows,seed,len(y))
    source_cal=ProbabilityCalibrator(CALIBRATOR_PENALTY).fit(raw[source_fit],y[source_fit])

    can_counts,learn_counts,ceiling=budget_schedule(windows)
    cohorts={}
    pending={}
    pred=raw.copy()
    oracle_pred=raw.copy()
    traces=[]
    total_requested=0

    for t,ix in enumerate(windows):
        # Release one-window-delayed learner labels that become usable now.
        for origin,items in pending.pop(t,[]):
            cohorts.setdefault(origin,{"indices":windows[origin],"observed":[],"canary_count":0})
            cohorts[origin]["observed"].extend(items)

        # Freeze expert candidates from labels available before current canaries.
        candidates={}
        metas={}
        for name,spec in EXPERTS.items():
            q,meta=fit_candidate(
                raw,y,source_fit,source_cal,roles,cohorts,t,seed,
                spec["history_fraction"],spec["reuse"]
            )
            candidates[name]=q[ix]
            metas[name]=meta

        rng=np.random.default_rng(stable_seed("multi_expert_canary",dataset,seed,t))
        strata,canary,bulk=canary_design(raw[ix],candidates,int(can_counts[t]),rng)
        total_requested += len(canary)
        local_y=y[ix]

        # Same current canaries evaluate every expert.
        estimates={}
        for name,q in candidates.items():
            estimates[name]=estimate_candidate(
                raw[ix],q,local_y,strata,bulk,len(candidates)
            )

        # Current-utility router.
        #
        # The previous development probe required a simultaneous conservative
        # lower confidence bound to be positive before any expert could act.
        # Its trace showed that this radius dominated D_hat and forced an
        # almost-always-raw policy despite a very strong oracle ceiling.
        #
        # Here the current canary estimator itself is used for routing:
        #   G_hat_j(eta_j) = 2 D_hat_j eta_j - C_j eta_j^2,
        #   eta_j = clip(D_hat_j / C_j, 0, 1).
        #
        # Raw remains an explicit expert with score 0. No dataset identity,
        # historical outcome, or bulk label enters the decision.
        best_name="raw"; best_score=0.0
        for name,est in estimates.items():
            score=float(est["gain_hat"])
            if score>best_score:
                best_name=name; best_score=score

        out=raw[ix].copy()
        chosen_eta=0.0
        if best_name!="raw" and len(bulk):
            est=estimates[best_name]
            chosen_eta=est["eta"]
            q=candidates[best_name]
            out[bulk]=probabilities(raw[ix][bulk]+chosen_eta*(q[bulk]-raw[ix][bulk]))
        out[canary]=raw[ix][canary]
        pred[ix]=out

        # Retrospective ceiling only: best expert/eta using true bulk labels.
        oracle_best="raw"; oracle_brier=float(np.mean(brier_rows(raw[ix][bulk],local_y[bulk]))) if len(bulk) else float(np.mean(brier_rows(raw[ix],local_y)))
        oracle_eta=0.0
        oracle_out=raw[ix].copy()
        if len(bulk):
            for name,q in candidates.items():
                d=q-raw[ix]
                yy=local_y[bulk]
                z=d[bulk,yy]-np.sum(raw[ix][bulk]*d[bulk],axis=1)
                D=float(np.mean(z))
                C=float(np.mean(np.sum(d[bulk]**2,axis=1)))
                eta=float(np.clip(D/C,0,1)) if C>1e-18 else 0.0
                cand=probabilities(raw[ix][bulk]+eta*d[bulk])
                b=float(np.mean(brier_rows(cand,yy)))
                if b<oracle_brier:
                    oracle_brier=b; oracle_best=name; oracle_eta=eta
                    oracle_out[bulk]=cand
            oracle_out[canary]=raw[ix][canary]
        oracle_pred[ix]=oracle_out

        H=exact_H(raw[ix],out)
        raw_b=float(np.mean(brier_rows(raw[ix],local_y)))
        routed_b=float(np.mean(brier_rows(out,local_y)))

        trace={
            "dataset":dataset,"seed":seed,"window":t+1,
            "window_n":len(ix),"canary_n":len(canary),
            "learner_n":int(learn_counts[t]),
            "chosen_expert":best_name,"chosen_eta":chosen_eta,
            "router_score":best_score,"exact_H":H,
            "raw_brier":raw_b,"routed_brier":routed_b,
            "realized_gain":raw_b-routed_b,
            "oracle_expert":oracle_best,"oracle_eta":oracle_eta,
            "oracle_bulk_brier":oracle_brier,
        }
        for name,est in estimates.items():
            trace[f"{name}_D_hat"]=est["D_hat"]
            trace[f"{name}_radius"]=est["radius"]
            trace[f"{name}_eta"]=est["eta"]
            trace[f"{name}_gain_hat"]=est["gain_hat"]
            trace[f"{name}_gain_lower"]=est["gain_lower"]
            trace[f"{name}_target_fit_n"]=metas[name]["target_n"]
            trace[f"{name}_target_ess"]=metas[name]["target_effective_size"]
        traces.append(trace)

        # Current canary labels become available immediately for FUTURE candidates.
        cohort=cohorts.setdefault(t,{"indices":ix,"observed":[],"canary_count":0})
        cohort["canary_count"]=len(canary)
        can_pi=len(canary)/len(ix) if len(ix) else 0.0
        for loc in canary:
            cohort["observed"].append({
                "row_id":int(ix[loc]),"label":int(local_y[loc]),
                "pi":float(can_pi),"kind":"canary"
            })

        # Random learner labels are requested after action and arrive one-window
        # later in feedback time, i.e. become effective for window t+2.
        lcount=int(learn_counts[t])
        if lcount>0:
            remaining=np.setdiff1d(np.arange(len(ix)),canary,assume_unique=True)
            rng_l=np.random.default_rng(stable_seed("router_learner",dataset,seed,t))
            locs=np.sort(rng_l.choice(remaining,size=lcount,replace=False))
            pi=lcount/len(remaining)
            items=[{
                "row_id":int(ix[loc]),"label":int(local_y[loc]),
                "pi":float(pi),"kind":"learner"
            } for loc in locs]
            release=t+2
            pending.setdefault(release,[]).append((t,items))
            total_requested += len(locs)

    must(total_requested==ceiling,f"budget mismatch {dataset} seed{seed}: {total_requested}!={ceiling}")

    routed=float(np.mean(brier_rows(pred[target],y[target])))
    raw_mean=float(np.mean(brier_rows(raw[target],y[target])))
    oracle=float(np.mean(brier_rows(oracle_pred[target],y[target])))
    return {
        "dataset":dataset,"seed":seed,"target_n":len(target),
        "label_ceiling":ceiling,"labels_requested":total_requested,
        "label_fraction":total_requested/len(target),
        "raw_brier":raw_mean,"router_brier":routed,
        "router_gain":raw_mean-routed,
        "router_relative_reduction":(raw_mean-routed)/raw_mean,
        "oracle_router_brier":oracle,
        "max_exact_H":max(x["exact_H"] for x in traces),
        "positive_windows":sum(x["realized_gain"]>0 for x in traces),
        "raw_windows":sum(x["chosen_expert"]=="raw" for x in traces),
        "thin40_windows":sum(x["chosen_expert"]=="thin40" for x in traces),
        "mid60_windows":sum(x["chosen_expert"]=="mid60" for x in traces),
        "full100_windows":sum(x["chosen_expert"]=="full100" for x in traces),
        "reuse100_windows":sum(x["chosen_expert"]=="reuse100" for x in traces),
    },pd.DataFrame(traces)

def summarize(seedwise):
    rows=[]
    for ds,g in seedwise.groupby("dataset"):
        rows.append({
            "dataset":ds,"seeds":len(g),
            "mean_raw_brier":float(g.raw_brier.mean()),
            "mean_router_brier":float(g.router_brier.mean()),
            "mean_router_gain":float(g.router_gain.mean()),
            "relative_reduction":float(g.router_gain.mean()/g.raw_brier.mean()),
            "positive_seeds":int((g.router_gain>0).sum()),
            "mean_oracle_router_brier":float(g.oracle_router_brier.mean()),
            "max_exact_H":float(g.max_exact_H.max()),
            "mean_label_fraction":float(g.label_fraction.mean()),
            "sparse_reference":SPARSE_REFERENCE[ds],
            "beats_strongest_sparse_reference":bool(g.router_brier.mean()<SPARSE_REFERENCE[ds]),
            "full_feedback_reference":FULL_FEEDBACK_REFERENCE[ds],
            "beats_full_feedback_reference":bool(g.router_brier.mean()<FULL_FEEDBACK_REFERENCE[ds]),
            "mean_raw_windows":float(g.raw_windows.mean()),
            "mean_thin40_windows":float(g.thin40_windows.mean()),
            "mean_mid60_windows":float(g.mid60_windows.mean()),
            "mean_full100_windows":float(g.full100_windows.mean()),
            "mean_reuse100_windows":float(g.reuse100_windows.mean()),
        })
    return pd.DataFrame(rows)

def main():
    OUT.mkdir(parents=True,exist_ok=True)
    print(
        "PLUGIN_ROUTER_5PCT_BEGIN "
        "budget=0.05 canary_share=0.20 learner_share=0.80 "
        "experts=thin40,mid60,full100,reuse100,raw fresh=false",
        flush=True
    )

    seed_rows=[]; traces=[]
    total=len(DATASETS)*len(SEEDS)
    job=0
    with threadpool_limits(limits=1):
        for ds in DATASETS:
            for seed in SEEDS:
                job+=1
                s,tr=run_seed(ds,seed)
                seed_rows.append(s); traces.append(tr)
                print(
                    f"PLUGIN_ROUTER_JOB {job}/{total} dataset={ds} seed={seed} "
                    f"raw={s['raw_brier']:.9f} router={s['router_brier']:.9f} "
                    f"oracle={s['oracle_router_brier']:.9f} "
                    f"Hmax={s['max_exact_H']:.9f}",
                    flush=True
                )

    seedwise=pd.DataFrame(seed_rows)
    trace=pd.concat(traces,ignore_index=True)
    summary=summarize(seedwise)

    gate=bool(summary.beats_strongest_sparse_reference.all())
    assessment={
        "diagnostic_only_postfreeze":True,
        "fresh_holdouts_touched":False,
        "architecture":"single 5% shared-stream multi-expert current-utility plug-in router",
        "development_gate":gate,
        "gate_definition":"mean Brier strictly beats strongest previously observed sparse-label reference on Bank, Electricity, and Gas",
        "per_dataset":{
            r.dataset:{
                "router_brier":float(r.mean_router_brier),
                "strongest_sparse_reference":float(r.sparse_reference),
                "beats_sparse":bool(r.beats_strongest_sparse_reference),
                "oracle_router_brier":float(r.mean_oracle_router_brier),
                "full_feedback_reference":float(r.full_feedback_reference),
                "beats_full_feedback":bool(r.beats_full_feedback_reference),
            } for _,r in summary.iterrows()
        },
        "if_pass":"Freeze the router architecture before any fresh validation; then rebuild affected ablations/robustness and obtain genuinely untouched confirmation.",
        "if_fail":"Use the oracle/router gap to identify whether routing estimation or expert capacity is the blocker. Do not start a new parameter sweep.",
    }

    seedwise.to_csv(OUT/"EXPERT_ROUTER_SEEDWISE.csv",index=False)
    trace.to_csv(OUT/"EXPERT_ROUTER_WINDOW_TRACE.csv",index=False)
    summary.to_csv(OUT/"EXPERT_ROUTER_SUMMARY.csv",index=False)
    (OUT/"EXPERT_ROUTER_ASSESSMENT.json").write_text(json.dumps(assessment,indent=2,sort_keys=True))
    manifest={
        "budget_fraction":TOTAL_BUDGET,
        "canary_budget_share":CANARY_BUDGET_SHARE,
        "learner_budget_share":LEARNER_BUDGET_SHARE,
        "learner_delay":DELAY,
        "buffer_windows":BUFFER_WINDOWS,
        "decay":DECAY,
        "source_mass":SOURCE_MASS,
        "router_alpha":ROUTER_ALPHA,
        "experts":EXPERTS,
        "expert_math":"recovered support_residual probability map; established primitive, not claimed as original",
        "new_components":[
            "single-budget shared-stream nested expert states",
            "multi-expert unlabeled repair-geometry canary design",
            "current-canary expert utility estimation",
            "raw/expert routing by plug-in Brier gain with raw score fixed at zero",
            "expert-specific risk-optimal interpolation",
            "exact prospective action-liability accounting without fixed .02 clipping",
        ],
        "no_fresh_holdouts":True,
        "no_base_model_training":True,
        "no_budget_sweep":True,
        "no_dataset_specific_router_rules":True,
    }
    (OUT/"EXPERT_ROUTER_MANIFEST.json").write_text(json.dumps(manifest,indent=2,sort_keys=True))

    review=PROJECT/"DTRAR_ExpertRouter_5pct_PluginRouter_Review.zip"
    tmp=review.with_suffix(".zip.partial")
    if tmp.exists(): tmp.unlink()
    with zipfile.ZipFile(tmp,"w",zipfile.ZIP_DEFLATED) as z:
        for p in sorted(OUT.iterdir()):
            if p.is_file(): z.write(p,p.name)
        z.write(Path(__file__),Path(__file__).name)
    with zipfile.ZipFile(tmp) as z:
        bad=z.testzip()
        if bad: raise RuntimeError(bad)
    tmp.replace(review)

    print("\n=== EXPERT ROUTER SUMMARY ===")
    print(summary.to_string(index=False))
    print("\n=== ASSESSMENT ===")
    print(json.dumps(assessment,indent=2,sort_keys=True))
    print(
        f"PLUGIN_ROUTER_5PCT_COMPLETE pass={str(gate).lower()} "
        f"review={review.name}",
        flush=True
    )

if __name__=="__main__":
    main()
